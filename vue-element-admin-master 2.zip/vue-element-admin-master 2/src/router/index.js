import Vue from 'vue'
import Router from 'vue-router'

Vue.use(Router)

export const constantRoutes = [
  {
    path: '/login',
    component: () => import('@/views/login/index'),
    hidden: true
  },
  {
    path: '/layout',
    component: () => import('@/views/layout'),
    hidden: true,
    children: [{
      path: '',
      component: () => import('@/views/home'),
      hidden: true
    },
    {
      path: '/wifisetting',
      component: () => import('@/views/basic-settings/wifi-setting'),
      hidden: true
    },
    {
      path: '/internetsetting',
      component: () => import('@/views/basic-settings/internet-settings'),
      hidden: true
    },
    {
      path: '/terminalsetting',
      component: () => import('@/views/basic-settings/terminal-settings'),
      hidden: true
    },
    {
      path: '/advancedsetting',
      component: () => import('@/views/basic-settings/advanced-settings'),
      hidden: true
    },
    {
      path: '/systeminfo',
      component: () => import('@/views/advanced-settings/systeminfo'),
      hidden: true
    },
    {
      path: '/wifiadvancedsetting',
      component: () => import('@/views/advanced-settings/wifiadvancedsetting'),
      hidden: true
    },
    {
      path: '/LANsetting',
      component: () => import('@/views/advanced-settings/LANsetting'),
      hidden: true
    }, {
      path: '/ipv6',
      component: () => import('@/views/advanced-settings/ipv6'),
      hidden: true
    }, {
      path: '/selectedapplication',
      component: () => import('@/views/advanced-settings/selectedapplication'),
      hidden: true
    },
    {
          path: '/adduser',
          component: () => import('@/views/advanced-settings/selected/adduser'),
          hidden: true
        },
        {
          path: '/ddns',
          component: () => import('@/views/advanced-settings/selected/ddns'),
          hidden: true
        },
        {
          path: '/firewall',
          component: () => import('@/views/advanced-settings/selected/firewall'),
          hidden: true
        },
        {
          path: '/flowStatistics',
          component: () => import('@/views/advanced-settings/selected/flowStatistics'),
          hidden: true
        },
        {
          path: '/ip',
          component: () => import('@/views/advanced-settings/selected/ip'),
          hidden: true
        },
        {
          path: '/iptv',
          component: () => import('@/views/advanced-settings/selected/iptv'),
          hidden: true
        },
        {
          path: '/mac',
          component: () => import('@/views/advanced-settings/selected/mac'),
          hidden: true
        }, {
          path: '/parent',
          component: () => import('@/views/advanced-settings/selected/parent'),
          hidden: true
        }, {
          path: '/QOS',
          component: () => import('@/views/advanced-settings/selected/QOS'),
          hidden: true
        },
        {
          path: '/transferPort',
          component: () => import('@/views/advanced-settings/selected/transferPort'),
          hidden: true
        },
        {
          path: '/upnp',
          component: () => import('@/views/advanced-settings/selected/upnp'),
          hidden: true
        },
        {
          path: '/url',
          component: () => import('@/views/advanced-settings/selected/url'),
          hidden: true
        },
        {
          path: '/vpn',
          component: () => import('@/views/advanced-settings/selected/vpn'),
          hidden: true
        },
    {
      path: '/changepwd',
      component: () => import('@/views/advanced-settings/changepwd'),
      hidden: true
    },
    {
      path: '/timesetting',
      component: () => import('@/views/advanced-settings/timesetting'),
      hidden: true
    },
    {
      path: '/ledsetting',
      component: () => import('@/views/advanced-settings/ledsetting'),
      hidden: true
    },
    {
      path: '/timedreboot',
      component: () => import('@/views/advanced-settings/timedreboot'),
      hidden: true
    },
    {
      path: '/systemlog',
      component: () => import('@/views/advanced-settings/systemlog'),
      hidden: true
    },
    {
      path: '/backupandrecover',
      component: () => import('@/views/advanced-settings/backupandrecover'),
      hidden: true
    },
    {
      path: '/rebootdevice',
      component: () => import('@/views/advanced-settings/rebootdevice'),
      hidden: true
    },
    {
      path: '/softwareupdate',
      component: () => import('@/views/advanced-settings/softwareupdate'),
      hidden: true
    }]
  },
  {
    path: '/404',
    component: () => import('@/views/error-page/404'),
    hidden: true
  },
  {
    path: '/401',
    component: () => import('@/views/error-page/401'),
    hidden: true
  },
  {
    path: '/',
    redirect: '/login'
  }
]

const createRouter = () => new Router({
  // mode: 'history', // require service support
  scrollBehavior: () => ({ y: 0 }),
  routes: constantRoutes
})

const router = createRouter()

export function resetRouter() {
  const newRouter = createRouter()
  router.matcher = newRouter.matcher // reset router
}

export default router
