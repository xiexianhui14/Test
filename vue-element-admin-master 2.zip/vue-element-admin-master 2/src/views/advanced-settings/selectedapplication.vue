<template>
  <div class="selected-application">
    <div class="selected-wrap">
      <router-link :to="item.name" v-for="(item,index) in selectedoptions" :key="index" 
>
<div class="item" :class="item.name" @mouseover="item.hover = true"
@mouseleave="item.hover = false">
<div class="img-wrap"><img :src="transfer(item.name, item.hover)"  class="selected-img" ></div>
      {{item.txt}}
</div>
      
      </router-link>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      hover:false,
      selectedoptions: [
        {
          txt: '访客网络',
          name: 'adduser',
          hover:false
        }, {
          txt: '家长控制',
          name: 'parent',
          hover:false
        }, {
          txt: '智能QOS',
          name: 'QOS',
          hover:false
        }, {
          txt: '防火墙',
          name: 'firewall',
          hover:false
        }, {
          txt: '端口转发',
          name: 'transferPort',
          hover:false
        }, {
          txt: 'VPN',
          name: 'vpn',
          hover:false
        }, {
          txt: 'DDNS',
          name: 'ddns',
          hover:false
        }, {
          txt: 'UPNP',
          name: 'upnp',
          hover:false
        }, {
          txt: 'IPTV',
          name: 'iptv',
          hover:false
        }, {
          txt: '流量统计',
          name: 'flowStatistics',
          hover:false
        }, {
          txt: 'MAC过滤',
          name: 'mac',
          hover:false
        }, {
          txt: 'IP过滤',
          name: 'ip',
          hover:false
        }, {
          txt: 'URL过滤',
          name: 'url',
          hover:false
        }
      ]
    }
  },
  methods:{
transfer(name,hover){
  console.log("jjj",this.hover)
  if(hover){
return require('../../assets/selected/'+name+'_active.png')
  }else{
return require('../../assets/selected/'+name+'.png')
  }
    
   }
  }
  
}
</script>
<style scoped lang="scss">
.selected-application{
  height:100%;
}
.selected-wrap{
  height:100%;
  
}
.item{
  display:inline-flex;
  flex-direction:column;
  align-items: center;
    justify-content: center;
  width:18%;
height: 31%;
margin-right:2.5%;
margin-bottom:1.95%;
background: #FFFFFF;
box-shadow: 0px 20px 40px 0px rgba(48, 56, 73, 0.15);
border-radius: 20px;


}
.item:hover{
  color:#fff;
background: linear-gradient(90deg, #15E2B1, #3D94F0);
box-shadow: 0px 20px 40px 0px rgba(48, 56, 73, 0.15);

}
.transferPort,.flowStatistics{
  margin-right:0;
}
.img-wrap{
  width:64px;
  height:64px;
}
.selected-img{
  width:64px;
  height:64px;
  margin-bottom:10px;

}
// .mac .selected-img{
//   width:76px;
//   height:28px;

// }
</style>