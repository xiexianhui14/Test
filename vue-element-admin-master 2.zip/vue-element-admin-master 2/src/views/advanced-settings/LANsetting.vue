<template>
  <div class="LAN-setting">
    <div class="LAN-wrap">
      <p class="tips">局域网IP地址解绑后，连续到路由器的其他设备会重新分配IP地址，当两台同网络的路由器汇同时， 修改局域网IP地址，可以有效避免</p>
      <p class="help">页面帮助</p>
      <div>
        <div class="wifi">
          <el-row :gutter="20">
            <el-col :span="10">DHCP服务器</el-col>
            <el-col :span="14">
              <div class="switch" />
              <el-switch v-model="dhcp_info.dhcp_switch" active-value="1" inactive-value="0" />
            </el-col>
          </el-row>
        </div>
        <div v-if="dhcp_info.dhcp_switch ==='1'">
          <div class="mode">
            <el-row :gutter="20">
              <el-col :span="10">路由器局域网IP地址</el-col>
              <el-col :span="14">
                192.168.
                <el-input-number
                  v-model="ip_section"
                  :controls="false"
                  :min="0"
                  :max="255"
                  class="mini"
                  placeholder
                />.1
              </el-col>
            </el-row>
          </div>
          <div class="mode">
            <el-row :gutter="20">
              <el-col :span="10">子网掩码</el-col>
              <el-col :span="14" class="netmask">
                {{ dhcp_info.netmask }}
              </el-col>
            </el-row>
          </div>
          <div class="mode">
            <el-row :gutter="20">
              <el-col :span="10">IP地址分配范围</el-col>
              <el-col :span="14">
                192.168.{{ ip_section }}.
                <el-input-number
                  v-model="dhcp_info.start"
                  :controls="false"
                  :min="1"
                  :max="254"
                  class="mini"
                  placeholder
                />
                <!-- <el-input v-model="dhcp_info.start" type="number" :controls="false" :min="1" :max="254" class="mini" placeholder="" />  -->
                -
                <el-input-number
                  v-model="dhcp_info.end"
                  :controls="false"
                  :min="1"
                  :max="254"
                  class="mini"
                  placeholder
                />
                <!-- <el-input v-model="dhcp_info.end" type="number" :min="1" :max="254" class="mini" placeholder="" /> -->
              </el-col>
            </el-row>
          </div>
          <div class="mode">
            <el-row :gutter="20">
              <el-col :span="10">DHCP租约时间</el-col>
              <el-col :span="14">
                <el-input-number
                  v-model="leasetime"
                  :controls="false"
                  :min="1"
                  :max="10080"
                  class="regular"
                  placeholder
                />
                (1~10080分钟)
              </el-col>
            </el-row>
          </div>
        </div>
      </div>

      <div class="save-wrap">
        <el-button type="primary" class="save" @click="save">保存</el-button>
      </div>
    </div>
  </div>
</template>
<script>
import { get_dhcp_info, set_dhcp } from '@/api/article'
export default {
  data() {
    return {
      dhcp_info: {
        dhcp_switch: '1',
        gateway: '192.168.6.1',
        netmask: '255.255.255.0',
        start: '2',
        end: '25',
        leasetime: '408'
      },
      ip_section: '',
      leasetime: '',
      num: ''
    }
  },
  created() {
    this.get_dhcp_info()
  },
  activated() {},
  deactivated() {},
  methods: {
    save() {
      this.set_dhcp()
    },
    get_dhcp_info() {
      get_dhcp_info().then(response => {
        this.dhcp_info = response.dhcp_info
        this.ip_section = this.dhcp_info.gateway.split('.')[2]
        console.log('this.ip_sectiowwn', this.dhcp_info.gateway)
        console.log('this.ip_section', this.ip_section)
        this.leasetime = parseInt(parseInt(response.dhcp_info.leasetime) / 60)
        this.dhcp_info.leasetime = this.leasetime + 'm'
      })
    },
    set_dhcp() {
      if (parseInt(this.dhcp_info.start) > parseInt(this.dhcp_info.end)) {
        this.$message({
          message: '起始数字大于结尾数字',
          type: 'error',
          duration: 2 * 1000
        })
        return
      }
      this.dhcp_info.gateway =
        this.dhcp_info.gateway.split('.')[0] +
        '.' +
        this.dhcp_info.gateway.split('.')[1] +
        '.' +
        this.ip_section +
        '.' +
        this.dhcp_info.gateway.split('.')[3]
      set_dhcp(this.dhcp_info).then(response => {
        this.$message({
          message: '成功',
          type: 'success',
          duration: 2 * 1000
        })
      })
    }
  }
}
</script>
<style scoped lang='scss'>
.LAN-setting {
  width: 100%;
  min-height: 100%;
  background: rgba(255, 255, 255, 1);
  box-shadow: 0px 20px 40px 0px rgba(48, 56, 73, 0.15);
  border-radius: 20px;
  .txt,
  .tips,
  .help {
    text-align: left;
  }
  .title {
    font-size: 20px;
    font-weight: 600;
    margin-bottom: 10px;
  }
  .tips {
    margin-top: 10px;
  }
  .help {
    color: #53a9fd;
    cursor: pointer;
  }
  ::v-deep .el-col-10 {
    text-align: right;
    height: 36px;
    line-height: 36px;
  }
  ::v-deep .el-col-14 {
    text-align: left;
  }
  ::v-deep .el-input-number--medium .el-input__inner {
    width: 66px;
  }

    ::v-deep .regular.el-input-number--medium .el-input__inner {
      width: 200px !important;
      text-align: left;
    }

  .netmask {
    height: 36px;
    line-height: 36px;
  }
}
.LAN-wrap {
  width: 800px;
  margin: 0 auto;
  text-align: center;
  padding-top: 24px;
  padding-bottom: 24px;
}
.mini {
  width: 66px;
}
.input-wrap,
.select-wrap {
  margin-top: 22px;
}
.priority,
.wifi {
  margin-top: 14px;
  ::v-deep .el-col-10 {
    margin-top: -6px;
  }
}
.mode {
  margin-top: 22px;
}

.save-wrap {
  // margin-left: 26%;
}
.save {
  margin-top: 20px;
}
</style>
