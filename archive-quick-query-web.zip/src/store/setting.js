export default {
    state: {
        background: '#002140'
    }
  }
  