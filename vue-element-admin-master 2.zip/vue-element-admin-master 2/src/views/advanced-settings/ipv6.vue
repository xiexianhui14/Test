<template>
  <div>
    ipv6
  </div>
</template>
