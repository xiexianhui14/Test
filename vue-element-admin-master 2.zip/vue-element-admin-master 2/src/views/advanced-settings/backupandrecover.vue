<template>
  <div class="changepwd">
    <div class="pwd-wrap">
      <p class="txt title">备份配置</p>
      <p class="tips">将路由器的当前配置导出并保存在您的计算机中，今后若需要恢复3此配置，直接导入该备份文件即可。 提示：导出的配置文件会加密存储您的个人数据，请妥善保存。</p>
      <el-button type="primary" class="save" @click="exportfile">导出配置文件</el-button>
      <div>
        <p class="txt title">恢复配置</p>
        <el-row :gutter="20">
          <el-col :span="7" class="recover">选择您要恢复的配置文件</el-col>
          <el-col :span="10" class="recover">
            <el-input v-model="pwdForm.original_password" />
          </el-col>
          <el-col :span="7" class="recover">
            <el-upload
              class="upload-demo"
              ref="upload"
              action="https://jsonplaceholder.typicode.com/posts/"
              :on-preview="handlePreview"
              :on-remove="handleRemove"
              :file-list="fileList"
              :auto-upload="false"
            >
              <el-button slot="trigger" size="small" type="primary">选取文件</el-button>

              <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div>
            </el-upload>
          </el-col>
        </el-row>
        <el-button type="success" @click="submitUpload">导入配置文件</el-button>
        <el-button type="primary" class="save" @click="save">导入配置文件</el-button>
      </div>
      <div>
        <p class="txt title">恢复出厂配置</p>
        <p class="tips">恢复出厂后，路由器的配置将恢复到出厂状态。请慎用！建议宁在恢复出厂前备份当前配置。</p>
        <div class="detect">
          <el-row :gutter="20">
            <el-col :span="10">恢复出厂保留关键配置</el-col>
            <el-col :span="14" class="switch">
              <el-switch v-model="value1" />
              <p class="note">重新配置路由器时，自动帮您填写网络配置</p>
            </el-col>
          </el-row>
        </div>
        <el-button type="primary" class="save" @click="save">恢复出厂配置</el-button>
      </div>
    </div>
  </div>
</template>
<script>
import { set_param_operate } from '@/api/article'
import { validLoginPwd } from '@/utils/validate'
import { saveAs } from 'file-saver'
import JSZip from 'jszip'
export default {
  data() {
    const validatePwd = (rule, value, callback) => {
      if (!validLoginPwd(value)) {
        callback(new Error('请输入正确的登录密码!'))
      } else {
        callback()
      }
    }

    return {
      pwdForm: {
        username: '',
        original_password: '',
        new_password: '',
        confirm_password: ''

      },
      pwdRules: {
        original_password: [
          { required: true, trigger: 'blur', validator: validatePwd }
        ],
        new_password: [
          { required: true, trigger: 'blur', validator: validatePwd }
        ],
        confirm_password: [
          { required: true, trigger: 'blur', validator: validatePwd }
        ]

      }
    }
  },
  created() {
    // this.get_login_info()
  },
  activated() {},
  deactivated() {},
  methods: {
    save() {
      this.$refs.pwdForm.validate(valid => {
        if (valid) {
          this.set_login()
        }
      })
    },
    downFileBlob (fileData, fileType, fileName) {
      let blobData = fileData
      let contentType = ''

      if (fileType === 'image') {
        //图片
        let parts = fileData.split(';base64,');
        contentType = parts[0].split(':')[1];
        let raw = window.atob(parts[1]);
        let rawLength = raw.length;
        let uInt8Array = new Uint8Array(rawLength);
        for (let i = 0; i < rawLength; ++i) {
          uInt8Array[i] = raw.charCodeAt(i);
        }
        blobData = uInt8Array
      } else if (fileType === 'zip') {
        contentType = 'application/x-targz'
      }

      const link = document.createElement('a')
      let blob = new Blob([blobData], {
        type: contentType
      })
      link.style.display = 'none'
      link.href = URL.createObjectURL(blob)

      link.download = fileName
      document.body.appendChild(link)
      link.click()
      document.body.removeChild(link)
    },
    base64ToToBlob(base64Data, contentType) { 
            var bytes64 = atob(base64Data);
            var byteData = new ArrayBuffer(bytes64.length);//内存区域
            var array = new Uint8Array(byteData);//8位无符号整数
            for (var i = 0; i < bytes64.length; i++) {
                array[i] = bytes64.charCodeAt(i);//字符的 Unicode 编码
            }
            return new Blob([byteData], { type: contentType });
         },
         exportfile(){
           const params = "operate=export_cfg"
       set_param_operate(params,'blob').then(res => {
         let blob = new Blob([res.data], { type: 'application/x-targz' });
        //解码前的文件名
        let fileName1=res.headers['content-disposition'].split("=")[1].split(".")[0].replace('"',"");
        //解码
        let fileName=decodeURIComponent(fileName1);
        var filename = fileName+".tar.gz";
        var a = document.createElement('a');
        var url = window.URL.createObjectURL(blob);
        a.href = url;
        a.download = filename;
        var body = document.getElementsByTagName('body')[0];
        body.appendChild(a);
        a.click();
        body.removeChild(a);
        window.URL.revokeObjectURL(url);
         })
         },
          exportTxt(){
     let res = this.logdata
 let blob = new Blob([res.data], { type: 'application/x-targz' });
        //解码前的文件名
        let fileName1=res.headers['content-disposition'].split("=")[1].split(".")[0].replace('"',"");
        //解码
        let fileName=decodeURIComponent(fileName1);
        var filename = fileName+".txt";
        var a = document.createElement('a');
        var url = window.URL.createObjectURL(blob);
        a.href = url;
        a.download = filename;
        var body = document.getElementsByTagName('body')[0];
        body.appendChild(a);
        a.click();
        body.removeChild(a);
        window.URL.revokeObjectURL(url);
   },
          exportfileaaa(){
      var zip = new JSZip();
      var myFile = zip.folder(); // 新建一个myFile文件夹
            myFile.file('办理毕业生户籍迁入操作指引.doc', base64, {
                base64: true
            }); // 文件名称
     
            zip.generateAsync({ type: 'blob' }).then(function(content) {
                // see FileSaver.js
                saveAs(content, '办理毕业生户籍迁入操作指引.zip');
            })
          },
//     exportfile(){
//       var zip = new JSZip();
//       var myFile = zip.folder(); // 新建一个myFile文件夹
//             myFile.file('办理毕业生户籍迁入操作指引.doc', base64, {
//                 base64: true
//             }); // 文件名称
     
//             zip.generateAsync({ type: 'blob' }).then(function(content) {
//                 // see FileSaver.js
//                 saveAs(content, '办理毕业生户籍迁入操作指引.zip');

 
// zip.file("Hello.txt", "Hello World\n");
 
// var img = zip.folder("images");
// // img.file("smile.gif", imgData, {base64: true});
 
// zip.generateAsync({type:"blob"}).then(function(content) {
//     // see FileSaver.js
//     saveAs(content, "example.zip");
// });
//       const params = "operate=export_cfg"
//       set_param_operate(params).then(res => {
//         // let blob = new Blob([res.data], { type: 'application.zip' });
//         // //解码前的文件名
//         // let fileName1=res.headers['content-disposition'].split("=")[1].split(".")[0].replace('"',"");
//         // //解码
//         // let fileName=decodeURIComp
//         // onent(fileName1);
//         // var filename = fileName+".tar.gz";
//         var a = document.createElement('a');
//         var arr=this.base64ToToBlob(res.data,'zip')
// var url=''
// JSZip.loadAsync(arr).then(function(zip) {
//       zip.forEach(function (relativePath, zipEntry) {
//            if(!zipEntry.dir){
//                zip.file(zipEntry.name).async('blob').then((e)=>{
//                    var url = window.URL.createObjectURL(e);
//                    //此方法可以获取到多种格式数据  但是只支持显示图片
//                   	//blobuel为图片路径  直接绑定页面即可                               
//                })
//            }
//       })
// })
//         a.href = url;
//         a.download = "filename.tar.gz";
//         var body = document.getElementsByTagName('body')[0];
//         body.appendChild(a);
//         a.click();
//         body.removeChild(a);
//         window.URL.revokeObjectURL(url);
//       })
     
//    },
    get_login_info() {
      get_login_info().then(response => {
        this.pwdForm.username = response.login_info.username
      })
    },
    set_login() {
      if (this.pwdForm.new_password !== this.pwdForm.confirm_password) {
        this.$message({
          message: '两次密码输入不同！',
          type: 'error',
          duration: 2 * 1000
        })
        return
      }
      const params = {
        username: this.pwdForm.username,
        original_password: this.pwdForm.original_password,
        new_password: this.pwdForm.new_password
      }
      set_login(params).then(response => {
        this.$message({
          message: '成功',
          type: 'success',
          duration: 2 * 1000
        })
      })
    }
  }
}
</script>
<style scoped lang='scss'>
.changepwd {
  width: 100%;
  min-height: 100%;
  background: rgba(255, 255, 255, 1);
  box-shadow: 0px 20px 40px 0px rgba(48, 56, 73, 0.15);
  border-radius: 20px;
  .txt,
  .tips {
    text-align: left;
    line-height: 24px;
  }
  .title {
    font-size: 20px;
    font-weight: 600;
    margin-bottom: 10px;
  }
  .tips {
    margin-top: 10px;
  }

  ::v-deep .el-col-10 {
    text-align: right;
    height: 36px;
    line-height: 36px;
  }
  ::v-deep .el-col-14 {
    text-align: left;
  }
}
.pwd-wrap {
  width: 800px;
  margin: 0 auto;
  text-align: center;
  padding-top: 24px;
  padding-bottom: 24px;
}
::v-deep .el-form-item__error {
  left: 45%;
}
.mini {
  width: 66px;
}
.input-wrap,
.select-wrap {
  margin-top: 22px;
}

.mode {
  margin-top: 22px;
}

.save-wrap {
  // margin-left: 26%;
}
.save {
  margin-top: 20px;
}
::v-deep .el-form-item__content {
  font-size: 18px;
}
.note {
  line-height: 15px;
  font-size: 12px;
  color: rgba(48, 56, 73, 1);
  margin: 5px 0;
}
.recover {
  text-align: left;
  height: 36px;
  line-height: 36px;
}
.choose {
  margin-top: -8px;
  background: #53aafe;
}
.switch {
  margin-top: 8px;
}
</style>
