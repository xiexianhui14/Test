<template>
  <div class="led-setting">
    <div class="led-wrap">
      <div class="led">
        <el-row :gutter="20">
          <el-col :span="12" class="name">
            <p class="title">LED设置</p>
            LED开关
          </el-col>
          <el-col :span="12" class="content">
            <div class="switch" />
            <el-switch v-model="led_switch" active-value="1" inactive-value="0" @change="switchLed" />
          </el-col>
        </el-row>
      </div>
    </div>
  </div>
</template>
<script>
import { get_led_info, set_led } from '@/api/article'
export default {
  data() {
    return {
      led_switch: '1'
    }
  },
  created() {
    this.get_led_info()
  },
  activated() {},
  deactivated() {},
  methods: {
    get_led_info() {
      get_led_info().then(response => {
        this.led_switch = response.led_info.led_switch
      })
    },
    switchLed() {
      const params = {
        led_switch: this.led_switch

      }
      set_led(params).then(response => {
        this.$message({
          message: '成功',
          type: 'success',
          duration: 2 * 1000
        })
      })
    }
  }
}
</script>
<style scoped lang='scss'>
.led-setting {
  width: 100%;
  min-height: 100%;
  padding-top:40px;
  background: rgba(255, 255, 255, 1);
  box-shadow: 0px 20px 40px 0px rgba(48, 56, 73, 0.15);
  border-radius: 20px;
  .title {
    font-size: 20px;
    font-weight: 600;
    margin-bottom: 20px;
    margin-right: -8px;
  }

}
.name{
  text-align: right;
}
.content{
  margin-top: 62px;
}
</style>
