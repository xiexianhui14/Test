<template>
  <div class="changepwd">
    <div class="pwd-wrap">
      <p class="txt title">修改登录密码</p>
      <p class="tips">访问路由器Web配置界面需要输入正确的密码。经常修改登录密码。可以降低被黑客攻击和破解的风险。</p>
      <p class="help">页面帮助</p>
      <el-form
        ref="pwdForm"
        :model="pwdForm"
        :rules="pwdRules"
        class="pwd-form"
        autocomplete="on"
        label-position="left"
      >
        <el-form-item class="input-wrap" prop="original_password">
          <el-row :gutter="20">
            <el-col :span="10">当前密码</el-col>
            <el-col :span="14">
              <el-input v-model="pwdForm.original_password" placeholder="请输入旧密码" show-password />
            </el-col>
          </el-row>
        </el-form-item>
        <el-form-item class="input-wrap" prop="new_password">
          <el-row :gutter="20">
            <el-col :span="10">新密码</el-col>
            <el-col :span="14">
              <el-input v-model="pwdForm.new_password" placeholder="请输入新密码" show-password />
            </el-col>
          </el-row>
        </el-form-item>
        <el-form-item class="input-wrap" prop="confirm_password">
          <el-row :gutter="20">
            <el-col :span="10">确认新密码</el-col>
            <el-col :span="14">
              <el-input v-model="pwdForm.confirm_password" placeholder="请确认新密码" show-password />
            </el-col>
          </el-row>
        </el-form-item>
      </el-form>

      <div class="save-wrap">
        <el-button type="primary" class="save" @click="save">保存</el-button>
      </div>
    </div>
  </div>
</template>
<script>
import { get_login_info, set_login } from '@/api/article'
import { validLoginPwd } from '@/utils/validate'
export default {
  data() {
    const validatePwd = (rule, value, callback) => {
      if (!validLoginPwd(value)) {
        callback(new Error('请输入正确的登录密码!'))
      } else {
        callback()
      }
    }

    return {
      pwdForm: {
        username: '',
        original_password: '',
        new_password: '',
        confirm_password: ''

      },
      pwdRules: {
        original_password: [
          { required: true, trigger: 'blur', validator: validatePwd }
        ],
        new_password: [
          { required: true, trigger: 'blur', validator: validatePwd }
        ],
        confirm_password: [
          { required: true, trigger: 'blur', validator: validatePwd }
        ]

      }
    }
  },
  created() {
    this.get_login_info()
  },
  activated() {},
  deactivated() {},
  methods: {
    save() {
      this.$refs.pwdForm.validate(valid => {
        if (valid) {
          this.set_login()
        }
      })
    },
    get_login_info() {
      get_login_info().then(response => {
        this.pwdForm.username = response.login_info.username
      })
    },
    set_login() {
      if (this.pwdForm.new_password !== this.pwdForm.confirm_password) {
        this.$message({
          message: '两次密码输入不同！',
          type: 'error',
          duration: 2 * 1000
        })
        return
      }
      const params = {
        username: this.pwdForm.username,
        original_password: this.pwdForm.original_password,
        new_password: this.pwdForm.new_password
      }
      set_login(params).then(response => {
        this.$message({
          message: '成功',
          type: 'success',
          duration: 2 * 1000
        })
      })
    }
  }
}
</script>
<style scoped lang='scss'>
.changepwd {
  width: 100%;
  min-height: 100%;
  background: rgba(255, 255, 255, 1);
  box-shadow: 0px 20px 40px 0px rgba(48, 56, 73, 0.15);
  border-radius: 20px;
  .txt,
  .tips,
  .help {
    text-align: left;
  }
  .title {
    font-size: 20px;
    font-weight: 600;
    margin-bottom: 10px;
  }
  .tips {
    margin-top: 10px;
  }
  .help {
    color: #53a9fd;
    cursor: pointer;
  }
  ::v-deep .el-col-10 {
    text-align: right;
    height: 36px;
    line-height: 36px;
  }
  ::v-deep .el-col-14 {
    text-align: left;
  }

}
.pwd-wrap {
  width: 800px;
  margin: 0 auto;
  text-align: center;
  padding-top: 24px;
  padding-bottom: 24px;
}
::v-deep .el-form-item__error{
 left:45%;
}
.mini {
  width: 66px;
}
.input-wrap,
.select-wrap {
  margin-top: 22px;
}

.mode {
  margin-top: 22px;
}

.save-wrap {
  // margin-left: 26%;
}
.save {
  margin-top: 20px;
}
::v-deep .el-form-item__content{
  font-size: 18px;
}
</style>
