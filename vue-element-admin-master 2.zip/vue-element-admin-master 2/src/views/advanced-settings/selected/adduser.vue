<template>
  <div class="adduser">
    <div class="user-wrap">
      <p class="txt title">访客网络</p>
      <p class="tips">
        当您家里来客人时，可以开启客人Wi-Fi功能。这样，您家将同时拥有主Wi-Fi和客人Wi-Fi这两个独立的Wi-Fi网络，
        客人虽然可以通过专属Wi-Fi上网，但不能管理您的路由器，也不能访问您家庭网络中的设备，客人Wi-Fi有效保证了您的网络隐私安全。
      </p>
      <p class="help">页面帮助</p>
     
        <div class="wifi">
          <el-row :gutter="20">
            <el-col :span="10">客人Wi-Fi</el-col>
            <el-col :span="14">
              <div class="switch" />
              <el-switch v-model="guest_wifi_info.disabled" active-value="0" inactive-value="1" />
            </el-col>
          </el-row>
        </div>
        <div v-if="guest_wifi_info.disabled==='0'">
          <div class="input-wrap">
            <el-row :gutter="20">
              <el-col :span="10">客人Wi-Fi名称</el-col>
              <el-col :span="14">
                <el-input v-model="guest_wifi_info.ssid" placeholder="请输入内容" />
              </el-col>
            </el-row>
          </div>
          <div class="mode">
            <el-row :gutter="20">
              <el-col :span="10">开启时长</el-col>
              <el-col :span="14">
                <el-select v-model="guest_wifi_info.timelong" clearable placeholder="请选择">
                  <el-option
                    v-for="item in timelongoptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  />
                </el-select>
              </el-col>
            </el-row>
          </div>
          <div class="mode">
            <el-row :gutter="20">
              <el-col :span="10">安全</el-col>
              <el-col :span="14">
                <el-select v-model="guest_wifi_info.encrypt_switch" clearable placeholder="请选择">
                  <el-option
                    v-for="item in securityoptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  />
                </el-select>
                <div v-if="guest_wifi_info.encrypt_switch===0" class="note">
                  <i class="el-icon-warning" />WiFi不加密，有被他人盗用的风险，请及时设置WiFi密码
                </div>
              </el-col>
            </el-row>
          </div>
          <div v-if="guest_wifi_info.encrypt_switch!==0">
            <div class="input-wrap">
              <el-row :gutter="20">
                <el-col :span="10">WiFi密码</el-col>
                <el-col :span="14">
                  <el-input v-model="guest_wifi_info.key" placeholder="请输入密码" show-password />
                </el-col>
              </el-row>
            </div>
          </div>
        
  

      <div class="save-wrap">
        <el-button type="primary" class="save" @click="save">保存</el-button>
      </div>
      <div class="last-time">
        <el-row :gutter="20">
          <el-col :span="10" class="time-txt">剩余时间</el-col>
          <el-col :span="14">
            <span class="time">23</span>小时
            <span class="time">59</span>分钟
            <span class="time">59</span>秒
          </el-col>
        </el-row>
      </div>
      </div>
    </div>
  </div>
</template>
<script>
import { get_guest_wifi_info, set_guest_wifi } from "@/api/article";
import { validLoginPwd } from "@/utils/validate";
export default {
  data() {
  

    return {
      guest_wifi_info: {
        encrypt_switch: 1,
        band_index: "2",
        disabled: "1",
        timelong: "4h",
        key: "12345678",
        ssid: "guest_ap_5g",
      },
      securityoptions: [
        {
          value: 0,
          label: "不加密",
        },
        {
          value: 1,
          label: "加密",
        },
      ],
      timelongoptions: [
        {
          value: "4h",
          label: "4小时",
        },
        {
          value: "24h",
          label: "24小时",
        },
        {
          value: "unlimit",
          label: "不限时",
        },
      ]
    }
  },
  created() {
    this.get_guest_wifi_info()
  },
  activated() {},
  deactivated() {},
  methods: {
    save() {
      this.set_guest_wifi()
    },
    get_guest_wifi_info() {
      const params={
        "band_index":"2"
      }
      get_guest_wifi_info(params).then((response) => {
        this.guest_wifi_info = response.guest_wifi_info;
      });
    },
    set_guest_wifi() {
      set_guest_wifi(this.guest_wifi_info).then((response) => {
        this.$message({
          message: "成功",
          type: "success",
          duration: 2 * 1000,
        });
      });
    },
  },
};
</script>
<style scoped lang='scss'>
.adduser {
  width: 100%;
  min-height: 100%;
  background: rgba(255, 255, 255, 1);
  box-shadow: 0px 20px 40px 0px rgba(48, 56, 73, 0.15);
  border-radius: 20px;
  .txt,
  .tips,
  .help {
    text-align: left;
  }
  .title {
    font-size: 20px;
    font-weight: 600;
    margin-bottom: 10px;
  }
  .tips {
    margin-top: 10px;
  }
  .help {
    color: #53a9fd;
    cursor: pointer;
  }
  ::v-deep .el-col-10 {
    text-align: right;
    height: 36px;
    line-height: 36px;
  }
  ::v-deep .el-col-14 {
    text-align: left;
  }
}
.user-wrap {
  width: 800px;
  margin: 0 auto;
  text-align: center;
  padding-top: 24px;
  padding-bottom: 24px;
}
::v-deep .el-form-item__error {
  left: 45%;
}
.mini {
  width: 66px;
}
.input-wrap,
.select-wrap {
  margin-top: 22px;
}

.mode {
  margin-top: 22px;
}

.save-wrap {
  // margin-left: 26%;
}
.save {
  margin-top: 20px;
}
::v-deep .el-form-item__content {
  font-size: 18px;
}
.switch{
  margin-top: 6px;
}
.time-txt{
  margin-top: 10px;
}
.last-time {
  margin-top: 20px;
}
.time {
  font-size: 40px;
  font-weight: bold;
  color: #15e3af;
}
.note {
  line-height: 15px;
  font-size: 12px;
  color: rgba(48, 56, 73, 1);
  margin: 5px 0;
}
.el-icon-warning{
  color:red;
  font-size: 18px;
  margin-right: 5px;
}
</style>
