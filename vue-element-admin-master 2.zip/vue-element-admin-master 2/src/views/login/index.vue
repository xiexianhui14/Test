<template>
  <div class="login-container">
    <div>
      <img src="../../assets/login/logo.png"
           width="139"
           height="32"
           alt="logo"
           class="logo">
    </div>
    <el-dropdown>
      <span class="el-dropdown-link">
        中文
        <i class="el-icon-arrow-down el-icon--right" />
      </span>
      <el-dropdown-menu slot="dropdown">
        <el-dropdown-item>中文</el-dropdown-item>
        <el-dropdown-item>English</el-dropdown-item>
      </el-dropdown-menu>
    </el-dropdown>
    <el-form ref="loginForm"
             :model="loginForm"
             :rules="loginRules"
             class="login-form"
             autocomplete="on"
             label-position="left">
      <el-tooltip v-model="capsTooltip"
                  content="Caps lock is On"
                  placement="right"
                  manual>
        <el-form-item prop="password"
                      label="管理员密码"
                      class="pwd-label">
          <el-input :key="passwordType"
                    ref="password"
                    v-model="loginForm.password"
                    :type="passwordType"
                    placeholder="密码"
                    name="password"
                    tabindex="2"
                    autocomplete="on"
                    @keyup.native="checkCapslock"
                    @blur="capsTooltip = false"
                    @keyup.enter.native="handleLogin" />
          <span class="show-pwd"
                :class="passwordType === 'password' ? 'close' : 'open'"
                @click="showPwd">
            <i class="el-icon-view" />
          </span>
        </el-form-item>
      </el-tooltip>
      <div class="forgetpwd">忘记密码？</div>
      <div class="btn-wrap">
        <el-button :loading="loading"
                   type="primary"
                   class="login-btn"
                   @click.native.prevent="handleLogin">登录</el-button>
      </div>
    </el-form>
  </div>
</template>

<script>
import { validUsername } from '@/utils/validate'
import { Message } from 'element-ui'
import { login } from '@/api/user'
export default {
  name: 'Login',
  data () {
    const validateUsername = (rule, value, callback) => {
      if (!validUsername(value)) {
        callback(new Error('Please enter the correct user name'))
      } else {
        callback()
      }
    }
    return {
      loginForm: {
        username: 'root',
        password: ''
      },
      loginRules: {
        username: [
          { required: true, trigger: 'blur', validator: validateUsername }
        ]
      },
      passwordType: 'password',
      capsTooltip: false,
      loading: false
    }
  },
  created () { },
  mounted () {
    if (this.loginForm.password === '') {
      this.$refs.password.focus()
    }
  },
  destroyed () { },
  methods: {
    checkCapslock (e) {
      const { key } = e
      this.capsTooltip = key && key.length === 1 && key >= 'A' && key <= 'Z'
    },
    showPwd () {
      if (this.passwordType === 'password') {
        this.passwordType = ''
      } else {
        this.passwordType = 'password'
      }
      this.$nextTick(() => {
        this.$refs.password.focus()
      })
    },
    handleLogin () {
      this.$refs.loginForm.validate(valid => {
        if (valid) {
          this.loading = true
          // this.$router.push({ path: '/layout' })
          localStorage.setItem('token', 'fdafda22f2fafd2a')
          this.$router.push({ path: '/mac' })
          return

          login(this.loginForm)
            .then(response => {
              console.log('response', response)
              if (response.code === 0) {
                localStorage.setItem('token', response.token)
                this.$router.push({ path: '/layout' })
              } else {
                Message({
                  message: response.msg,
                  type: 'error',
                  duration: 5 * 1000
                })
              }
              this.loading = false
            })
            .catch(() => {
              this.loading = false
            })
        } else {
          console.log('error submit!!')
          return false
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
$bg: #283443;
$light_gray: #fff;
$cursor: #fff;

@supports (-webkit-mask: none) and (not (cater-color: $cursor)) {
  .login-container .el-input input {
    color: $cursor;
  }
}

/* reset element-ui css */
.login-container {
  .logo {
    margin-top: 26px;
    margin-left: 49px;
  }
  .el-input {
    display: inline-block;
    height: 52px;
    width: 324px;
    border-radius: 20px;

    input {
      background: transparent;
      border: 0px;
      -webkit-appearance: none;
      border-radius: 0px;
      padding: 12px 5px 12px 15px;
      color: $light_gray;
      height: 52px;
      caret-color: $cursor;

      &:-webkit-autofill {
        box-shadow: 0 0 0px 1000px $bg inset !important;
        -webkit-text-fill-color: $cursor !important;
      }
    }
  }
  ::v-deep .el-form-item.pwd-label > .el-form-item__label:before {
    content: "" !important;
  }
  ::v-deep .el-form-item__label {
    line-height: 52px;
    font-size: 18px;
    color: white;
  }
  ::v-deep .el-dropdown {
    position: absolute;
    top: 26px;
    right: 49px;
    cursor: pointer;
    color: white;
  }
  ::v-deep .el-form-item {
    margin-bottom: 0;
  }
  ::v-deep .el-input--medium .el-input__inner {
    height: 52px;
    line-height: 52px;
    border-radius: 20px;
  }
  ::v-deep .el-form-item--medium .el-form-item__content {
    line-height: 52px;
    font-size: 18px;
  }
  .forgetpwd {
    margin-top: 20px;
    text-align: right;
    font-size: 18px;
    color: rgba(255, 255, 255, 1);
    cursor: pointer;
  }
  .btn-wrap {
    text-align: right;
    margin-right: 81px;
  }
  .login-btn {
    width: 179px;
    height: 52px;
    margin: 34px 0;
    border-color: transparent;
    background: rgba(20, 229, 173, 1);
    border-radius: 20px;
    font-size: 18px;
  }
}
</style>

<style lang="scss" scoped>
$bg: #2d3a4b;
$dark_gray: #889aa4;
$light_gray: #eee;

.login-container {
  min-height: 100%;
  width: 100%;
  background: url("../../assets/login/bg.jpg");
  overflow: hidden;

  .login-form {
    position: relative;
    width: 500px;
    max-width: 100%;
    padding: 16% 35px 0;
    margin: 0 auto;
    overflow: hidden;
  }

  .tips {
    font-size: 14px;
    color: #fff;
    margin-bottom: 10px;

    span {
      &:first-of-type {
        margin-right: 16px;
      }
    }
  }

  .show-pwd {
    position: absolute;
    right: 10px;
    top: 2px;
    font-size: 16px;
    color: $dark_gray;
    cursor: pointer;
    user-select: none;
  }
  .close {
    color: $dark_gray;
  }
  .open {
    color: #3d93f2;
  }
}
</style>
