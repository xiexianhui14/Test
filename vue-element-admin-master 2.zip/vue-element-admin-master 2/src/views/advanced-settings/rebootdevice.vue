<template>
  <div class="rebootdevice">

    <el-dialog
      title="设备重启"
      :visible.sync="centerDialogVisible"
      width="30%"
      :show-close="false"
      :close-on-click-modal="false"
      :close-on-press-escape="false"
      center
    >
      <i class="el-icon-loading" />
      <span slot="footer" class="dialog-footer">
        设备正在重启，请稍后...{{ reboottime }}
      </span>
    </el-dialog>
  </div>
</template>
<script>
import { set_reboot } from '@/api/article'

export default {
  data() {
    return {
      wan_info: {},
      wifi_info: {},
      device_info: {},
      runtime: '',
      timer: '',
      circleUrl:
        'https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png',
      centerDialogVisible: false,
      time: 0,
      reboottime: ''
    }
  },
  created() {
    // this.getdata()
  },
  mounted() {
    // this.reboot()
  },
  activated() {
    this.reboot()
    // this.timer = setInterval(this.getdata, 5000)
  },
  deactivated() {
    // clearInterval(this.timer)
  },
  methods: {
    addtime() {
      const that = this
      console.log('this.time', this.time)
      const timer = setInterval(function() {
        console.log('this.time', that.time)
        if (parseInt(that.time) < 70) {
          console.log('aadfafeee')
          that.time += 1
          that.reboottime = that.secondsFormatmin(that.time)
          console.log('this.time', that.time)
        } else {
          localStorage.removeItem('token')
          that.$router.push({ path: '/login' })
          console.log('agdfhdhadfaf')
          clearInterval(timer)
        }
      }, 1000)
    },
    rebootrouter() {
      // this.centerDialogVisible = true
      // this.addtime()
      const params = {
        reboot: 1
      }
      set_reboot(params).then(response => {
        this.centerDialogVisible = true
        this.addtime()
      })
    },
    // 格式化时间  重启
    secondsFormatmin(s) {
      console.log('s', s)
      if (s <= 60) {
        return s + '秒'
      } else {
        var minute = Math.floor((s) / 60)
        var second = s - minute * 60
        return minute + '分' + second + '秒'
      }
    },
    reboot() {
      this.$confirm(
        '是否重启设备，重启设备需要1分钟左右？',
        '提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
          center: true
        }
      )
        .then(() => {
          this.rebootrouter()
        })
        .catch(() => {
        })
    }
  }
}
</script>
<style scoped lang='scss'>
.rebootdevice{
     width: 100%;
  min-height: 100%;
  padding-top:40px;
  background: rgba(255, 255, 255, 1);
  box-shadow: 0px 20px 40px 0px rgba(48, 56, 73, 0.15);
  border-radius: 20px;
}
.el-row {
  height: 100%;
}
.el-col {
  height: 100%;
}

::v-deep .el-dialog--center{
  margin-top: calc(50vh - 140px) !important;
    width: 400px !important;
    height: 280px;
    border-radius: 20px;
}
::v-deep .el-dialog__title{
  font-weight: 600;
}
::v-deep .el-dialog--center .el-dialog__body{
  text-align: center;
}
.el-icon-loading{
  font-size: 56px;
  color: #3d93f2;
}
::v-deep .el-dialog__header {
    padding: 40px;
    padding-bottom: 25px;
}
::v-deep .el-dialog__footer {
    padding: 20px;
    padding-top: 25px;
}
</style>
