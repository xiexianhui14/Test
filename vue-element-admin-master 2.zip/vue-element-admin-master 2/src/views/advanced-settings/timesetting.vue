<template>
  <div class="time-setting">
    <div class="time-wrap">
      <p class="txt title">时间设置</p>
      <div>
        <div class="mode">
          <el-row :gutter="20">
            <el-col :span="10">系统时间</el-col>
            <el-col :span="14" class="current_time">
              {{ current_time }}
            </el-col>
          </el-row>
        </div>
        <div class="mode">
          <el-row :gutter="20">
            <el-col :span="10">
              时区设置
            </el-col>
            <el-col :span="14">
              <el-select v-model="timezone" clearable placeholder="请选择">
                <el-option
                  v-for="item in timezoneoptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-col>
          </el-row>
        </div>
      </div>

      <div class="save-wrap">
        <el-button type="primary" class="save" @click="save">保存并生效</el-button>
      </div>
    </div>
  </div>
</template>
<script>
import { get_system_time, set_system_time } from '@/api/article'
import { gettimejson } from '@/config/timejson'
export default {
  data() {
    return {
      current_time: '',
      timezone: '',
      timezoneoptions: [],
      sysData: {}
    }
  },
  created() {
    const timejson = gettimejson()
    for (let i = 0; i < timejson.length; i++) {
      this.timezoneoptions.push({
        value: timejson[i].zonename,
        label: timejson[i].zonename
      })
    }
    this.get_system_time()
  },
  activated() {},
  deactivated() {},
  methods: {
    save() {
      this.set_system_time()
    },
    get_system_time() {
      get_system_time().then(response => {
        this.current_time = response.ntp_info.current_time
        this.timezone = response.ntp_info.timezone
        this.sysData = response.ntp_info
      })
    },
    set_system_time() {
      this.sysData.timezone = this.timezone
      set_system_time(this.sysData).then(response => {
        this.$message({
          message: '成功',
          type: 'success',
          duration: 2 * 1000
        })
      })
    }
  }
}
</script>
<style scoped lang='scss'>
.time-setting {
  width: 100%;
  min-height: 100%;
  background: rgba(255, 255, 255, 1);
  box-shadow: 0px 20px 40px 0px rgba(48, 56, 73, 0.15);
  border-radius: 20px;
  .txt{
    text-align: left;
  }
  .title {
    font-size: 20px;
    font-weight: 600;
    margin-left: 31.2%;
    margin-bottom: 10px;
  }

  ::v-deep .el-col-10 {
    text-align: right;
    height: 36px;
    line-height: 36px;
  }
  ::v-deep .el-col-14 {
    text-align: left;
  }

}
.current_time{
  height: 36px;
  line-height: 36px;
}
.time-wrap {
  width: 800px;
  margin: 0 auto;
  text-align: center;
  padding-top: 24px;
  padding-bottom: 24px;
}
::v-deep .el-form-item__error{
 left:45%;
}
.mini {
  width: 66px;
}
.input-wrap,
.select-wrap {
  margin-top: 22px;
}

.mode {
  margin-top: 22px;
}

.save-wrap {
  // margin-left: 26%;
}
.save {
  margin-top: 20px;
}
</style>
