<template>
  <div class="softwareupdate">
    <div class="pwd-wrap">
      <p class="txt title">软件升级</p>
      <p class="help">软件升级</p>
      <p class="tips">新版本：   WMV1.0.20</p>
      <p class="tips">优化内容：1.优化产品体验，问题修复及性能优化。</p>

      <el-table
        :data="tableData"
        style="width: 100%"
      >

        <el-table-column
          prop="deviceName"
          label="设备名称"
          width="180"
        />
        <el-table-column
          prop="IP"
          label="IP地址"
          width="180"
        />
        <el-table-column
          prop="software"
          label="版本信息"
          width="180"
        />
        <el-table-column label="本地升级">
          <template slot-scope="scope">
            <el-button
              size="mini"
              class="local"
              @click="handleEdit(scope.$index, scope.row)"
            >本地升级</el-button>

          </template>
        </el-table-column>
        <el-table-column label="远程升级">
          <template slot-scope="scope">

            <el-button
              size="mini"
              class="long"
              @click="handleDelete(scope.$index, scope.row)"
            >远程升级</el-button>
          </template>
        </el-table-column>
      </el-table>

      <div class="save-wrap">
        <el-button type="primary" class="save" @click="save">重新监测</el-button>
      </div>
    </div>
  </div>
</template>
<script>
import { get_login_info, set_login } from '@/api/article'
export default {

  data() {
    return {
      tableData: [{
        deviceName: 'KS-MESSH-B2312A',
        IP: '192.168.6.106',
        software: 'WMV1.0.20'
      }, {
        deviceName: 'KS-MESSH-B2312A',
        IP: '192.168.6.106',
        software: 'WMV1.0.20'
      }, {
        deviceName: 'KS-MESSH-B2312A',
        IP: '192.168.6.106',
        software: 'WMV1.0.20'
      }]
    }
  },
  created() {
    // this.get_login_info()
  },
  activated() {},
  deactivated() {},
  methods: {
    handleEdit(index, row) {
      console.log(index, row)
    },
    handleDelete(index, row) {
      console.log(index, row)
    },
    save() {
      this.$refs.pwdForm.validate(valid => {
        if (valid) {
          this.set_login()
        }
      })
    },
    get_login_info() {
      get_login_info().then(response => {
        this.pwdForm.username = response.login_info.username
      })
    },
    set_login() {
      if (this.pwdForm.new_password !== this.pwdForm.confirm_password) {
        this.$message({
          message: '两次密码输入不同！',
          type: 'error',
          duration: 2 * 1000
        })
        return
      }
      const params = {
        username: this.pwdForm.username,
        original_password: this.pwdForm.original_password,
        new_password: this.pwdForm.new_password
      }
      set_login(params).then(response => {
        this.$message({
          message: '成功',
          type: 'success',
          duration: 2 * 1000
        })
      })
    }
  }
}
</script>
<style scoped lang='scss'>
.softwareupdate {
  width: 100%;
  min-height: 100%;
  background: rgba(255, 255, 255, 1);
  box-shadow: 0px 20px 40px 0px rgba(48, 56, 73, 0.15);
  border-radius: 20px;
  .txt,
  .tips,
  .help {
    text-align: left;
  }
  .title {
    font-size: 20px;
    font-weight: 600;
    margin-bottom: 10px;
  }
  .tips {
    margin-top: 10px;
  }
  .help {
    color: #53a9fd;
    cursor: pointer;
  }
  ::v-deep .el-col-10 {
    text-align: right;
    height: 36px;
    line-height: 36px;
  }
  ::v-deep .el-col-14 {
    text-align: left;
  }

}
.pwd-wrap {
  width: 800px;
  margin: 0 auto;
  text-align: center;
  padding-top: 24px;
  padding-bottom: 24px;
}
::v-deep .el-form-item__error{
 left:45%;
}
.mini {
  width: 66px;
}
.input-wrap,
.select-wrap {
  margin-top: 22px;
}

.mode {
  margin-top: 22px;
}

.save-wrap {
  // margin-left: 26%;
}
.save {
  margin-top: 20px;
}
.local{
  width:96px;
height:33px;
background:rgba(83,170,254,1);
border-radius:17px;
padding-left: 11px;
    padding-top: 6px;
}
.long{
  width:96px;
height:33px;
background:rgba(21,227,175,1);
border-radius:17px;
padding-left: 11px;
    padding-top: 6px;
}
</style>
