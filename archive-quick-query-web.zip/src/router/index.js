import Vue from 'vue'
import Router from 'vue-router'
import Login from '@/views/Login'

Vue.use(Router)

const commonRouter = [
    {
        path: '/',
        name: 'login',
        component: Login

    }
]

const router = new Router({
    mode: 'hash',
    routes: commonRouter
})
export default router