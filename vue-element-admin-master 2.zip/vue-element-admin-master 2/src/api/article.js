import request from '@/utils/request'

// 首页
export function home(data) {
  return request({
    url: ';stok=' + localStorage.getItem('token') + '/api/home/get_home_info',
    method: 'post',
    data
  })
}

/* 上网设置*/

// 获取连接状态
export function get_wan_status(data) {
  return request({
    url: ';stok=' + localStorage.getItem('token') + '/api/wan/get_wan_status',
    method: 'post',
    data
  })
}
// 重新连接
export function reconnect_wan(data) {
  return request({
    url: ';stok=' + localStorage.getItem('token') + '/api/wan/reconnect_wan',
    method: 'post',
    data
  })
}
// 获取网络配置
export function get_wan_info(data) {
  return request({
    url: ';stok=' + localStorage.getItem('token') + '/api/wan/get_wan_info',
    method: 'post',
    data
  })
}
// 设置网络配置
export function set_wan(data) {
  return request({
    url: ';stok=' + localStorage.getItem('token') + '/api/wan/set_wan',
    method: 'post',
    data
  })
}

// 退出登录

/* wifi 设置 */

// 获取wifi 信息
export function get_wifi_info(data) {
  return request({
    url: ';stok=' + localStorage.getItem('token') + '/api/wifi/get_wifi_info',
    method: 'post',
    data
  })
}
// 设置wifi信息
export function set_wifi(data) {
  return request({
    url: ';stok=' + localStorage.getItem('token') + '/api/wifi/set_wifi',
    method: 'post',
    data
  })
}
// 设置wifi功率
export function set_wifi_power(data) {
  return request({
    url: ';stok=' + localStorage.getItem('token') + '/api/wifi/set_wifi_power',
    method: 'post',
    data
  })
}

// 获取系统信息
export function get_system_info(data) {
  return request({
    url: ';stok=' + localStorage.getItem('token') + '/api/system/get_system_info',
    method: 'post',
    data
  })
}

// 重启
export function set_reboot(data) {
  return request({
    url: ';stok=' + localStorage.getItem('token') + '/api/system/set_reboot',
    method: 'post',
    data
  })
}

/* wifi 高级设置*/

// wifi 高级 获取
export function get_wifi_adv_info(data) {
  return request({
    url: ';stok=' + localStorage.getItem('token') + '/api/wifi/get_wifi_adv_info',
    method: 'post',
    data
  })
}

// wifi 高级 设置
export function set_wifi_adv(data) {
  return request({
    url: ';stok=' + localStorage.getItem('token') + '/api/wifi/set_wifi_adv',
    method: 'post',
    data
  })
}

/* lan 设置  */

// 获取局域网信息
export function get_dhcp_info(data) {
  return request({
    url: ';stok=' + localStorage.getItem('token') + '/api/lan/get_dhcp_info',
    method: 'post',
    data
  })
}
// 设置局域网
export function set_dhcp(data) {
  return request({
    url: ';stok=' + localStorage.getItem('token') + '/api/lan/set_dhcp',
    method: 'post',
    data
  })
}

/* 修改登录密码 */

// 获取login参数
export function get_login_info(data) {
  return request({
    url: ';stok=' + localStorage.getItem('token') + '/api/system/get_login_info',
    method: 'post',
    data
  })
}

// 设置login参数
export function set_login(data) {
  return request({
    url: ';stok=' + localStorage.getItem('token') + '/api/system/set_login',
    method: 'post',
    data
  })
}

/* 时区设置 */

// 获取系统时间数据
export function get_system_time(data) {
  return request({
    url: ';stok=' + localStorage.getItem('token') + '/api/system/get_system_time',
    method: 'post',
    data
  })
}

// 设置系统时间参数
export function set_system_time(data) {
  return request({
    url: ';stok=' + localStorage.getItem('token') + '/api/system/set_system_time',
    method: 'post',
    data
  })
}

/* led设置 */

// 获取led数据
export function get_led_info(data) {
  return request({
    url: ';stok=' + localStorage.getItem('token') + '/api/system/get_led_info',
    method: 'post',
    data
  })
}

// 设置led数据

export function set_led(data) {
  return request({
    url: ';stok=' + localStorage.getItem('token') + '/api/system/set_led',
    method: 'post',
    data
  })
}

/* 定时重启设置 */

// 获取定时重启数据
export function get_timed_reboot_info(data) {
  return request({
    url: ';stok=' + localStorage.getItem('token') + '/api/system/get_timed_reboot_info',
    method: 'post',
    data
  })
}

// 设置定时重启数据

export function set_timed_reboot(data) {
  return request({
    url: ';stok=' + localStorage.getItem('token') + '/api/system/set_timed_reboot',
    method: 'post',
    data
  })
}

/* 访客网络 */

// 获取访客网络数据

export function get_guest_wifi_info(data) {
  return request({
    url: ';stok=' + localStorage.getItem('token') + '/api/wifi/get_guest_wifi_info',
    method: 'post',
    data
  })
}

// 设置访客网络参数 

export function set_guest_wifi(data) {
  return request({
    url: ';stok=' + localStorage.getItem('token') + '/api/wifi/set_guest_wifi',
    method: 'post',
    data
  })
}

/*系统日志*/

// 获取系统日志

export function get_syslog(data) {
  return request({
    url: ';stok=' + localStorage.getItem('token') + '/api/system/get_syslog',
    method: 'post',
    data
  })
}

/*备份与恢复*/

export function set_param_operate(data,responseType) {
  return request({
    url: ';stok=' + localStorage.getItem('token') + '/api/system/set_param_operate',
    method: 'post',
    data,
    responseType
  })
}