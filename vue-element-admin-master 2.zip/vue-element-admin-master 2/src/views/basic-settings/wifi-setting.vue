<template>
  <div class="wifi-setting">
    <div class="wifi-wrap">
      <div class="priority">
        <el-row :gutter="20">
          <el-col :span="10">双频优选</el-col>
          <el-col :span="14">
            <div class="switch" @click="switchPriority" />
            <el-switch v-model="priority" active-value="1" inactive-value="2" />
            <p class="note">2.4G和5G Wi-Fi双频合一，路由器自动为您选择更快的 Wi-Fi 频</p>
            <p class="note">段，关闭此开关，即可单独设置</p>
          </el-col>
        </el-row>
      </div>
      <!-- 单频 -->
      <div v-if="priority==='1'">
        <div class="wifi">
          <el-row :gutter="20">
            <el-col :span="10">WiFi</el-col>
            <el-col :span="14">
              <div class="switch" @click="switchwifi" />
              <el-switch v-model="wifi" active-value="0" inactive-value="1" />
            </el-col>
          </el-row>
        </div>
        <div v-if="wifi==='0'">
          <div class="input-wrap">
            <el-row :gutter="20">
              <el-col :span="10">WiFi名称</el-col>
              <el-col :span="14">
                <el-input v-model="wifiname" placeholder="请输入内容" />
              </el-col>
            </el-row>
          </div>
          <div class="mode">
            <el-row :gutter="20">
              <el-col :span="10">安全</el-col>
              <el-col :span="14">
                <el-select v-model="security" clearable placeholder="请选择">
                  <el-option
                    v-for="item in securityoptions"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  />
                </el-select>
                <div v-if="security==='none'" class="note"><i class="el-icon-warning" />WiFi不加密，有被他人盗用的风险，请及时设置WiFi密码</div>
              </el-col>
            </el-row>
          </div>
          <div v-if="security!=='none'">
            <div class="mode">
              <el-row :gutter="20">
                <el-col :span="10">加密模式</el-col>
                <el-col :span="14">
                  <el-select v-model="encryption" clearable placeholder="请选择">
                    <el-option
                      v-for="item in encryptionoptions"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    />
                  </el-select>
                </el-col>
              </el-row>
            </div>
            <div class="input-wrap">
              <el-row :gutter="20">
                <el-col :span="10">WiFi密码</el-col>
                <el-col :span="14">
                  <el-input v-model="pwd" placeholder="请输入密码" show-password />
                </el-col>
              </el-row>
            </div>
          </div>
        </div>

        <div class="save-wrap">
          <el-button type="primary" class="save">保存</el-button>
        </div>
      </div>
      <!-- 单频 end -->
      <!-- 双频 -->
      <div v-else>
        <!-- 2.4g -->

        <div class="wifi">
          <el-row :gutter="20">
            <el-col :span="10">2.4G WiFi</el-col>
            <el-col :span="14">
              <div class="switch" @click="switch24g" />
              <el-switch v-model="wifi24g" active-value="0" inactive-value="1" />
            </el-col>
          </el-row>
        </div>
        <div v-if="wifi24g==='0'">
          <div class="input-wrap">
            <el-row :gutter="20">
              <el-col :span="10">WiFi名称</el-col>
              <el-col :span="14">
                <el-input v-model="wifiname24g" placeholder="请输入内容" />
              </el-col>
            </el-row>
          </div>
          <div class="mode">
            <el-row :gutter="20">
              <el-col :span="10">安全</el-col>
              <el-col :span="14">
                <el-select v-model="security24g" clearable placeholder="请选择">
                  <el-option
                    v-for="item in securityoptions24g"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  />
                </el-select>
                <div v-if="security24g==='none'" class="note"><i class="el-icon-warning" />WiFi不加密，有被他人盗用的风险，请及时设置WiFi密码</div>
              </el-col>
            </el-row>
          </div>
          <div v-if="security24g!=='none'">
            <div class="mode">
              <el-row :gutter="20">
                <el-col :span="10">加密模式</el-col>
                <el-col :span="14">
                  <el-select v-model="encryption24g" clearable placeholder="请选择">
                    <el-option
                      v-for="item in encryptionoptions24g"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    />
                  </el-select>
                </el-col>
              </el-row>
            </div>
            <div class="input-wrap">
              <el-row :gutter="20">
                <el-col :span="10">WiFi密码</el-col>
                <el-col :span="14">
                  <el-input v-model="pwd24g" placeholder="请输入密码" show-password />
                </el-col>
              </el-row>
            </div>
          </div>
        </div>

        <!-- 5g start-->
        <div class="wifi">
          <el-row :gutter="20">
            <el-col :span="10">5G WiFi</el-col>
            <el-col :span="14">
              <div class="switch" @click="switch5g" />
              <el-switch v-model="wifi5g" active-value="0" inactive-value="1" />
            </el-col>
          </el-row>
        </div>
        <div v-if="wifi5g==='0'">
          <div class="input-wrap">
            <el-row :gutter="20">
              <el-col :span="10">WiFi名称</el-col>
              <el-col :span="14">
                <el-input v-model="wifiname5g" placeholder="请输入内容" />
              </el-col>
            </el-row>
          </div>
          <div class="mode">
            <el-row :gutter="20">
              <el-col :span="10">安全</el-col>
              <el-col :span="14">
                <el-select v-model="security5g" clearable placeholder="请选择">
                  <el-option
                    v-for="item in securityoptions5g"
                    :key="item.value"
                    :label="item.label"
                    :value="item.value"
                  />
                </el-select>
                <div v-if="security5g==='none'" class="note"><i class="el-icon-warning" />WiFi不加密，有被他人盗用的风险，请及时设置WiFi密码</div>
              </el-col>
            </el-row>
          </div>
          <div v-if="security5g!=='none'">
            <div class="mode">
              <el-row :gutter="20">
                <el-col :span="10">加密模式</el-col>
                <el-col :span="14">
                  <el-select v-model="encryption5g" clearable placeholder="请选择">
                    <el-option
                      v-for="item in encryptionoptions5g"
                      :key="item.value"
                      :label="item.label"
                      :value="item.value"
                    />
                  </el-select>
                </el-col>
              </el-row>
            </div>
            <div class="input-wrap">
              <el-row :gutter="20">
                <el-col :span="10">WiFi密码</el-col>
                <el-col :span="14">
                  <el-input v-model="pwd5g" placeholder="请输入密码" show-password />
                </el-col>
              </el-row>
            </div>
          </div>
        </div>

        <!-- 5g end -->
        <div class="save-wrap">
          <el-button type="primary" class="save" @click="savewifi">保存</el-button>
        </div>
      </div>
      <div class="mode">
        <el-row :gutter="20">
          <el-col :span="10">WiFi功率模式</el-col>
          <el-col :span="14">
            <el-select v-model="power" clearable placeholder="请选择" @change="givetips">
              <el-option
                v-for="item in poweroptions"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-col>
        </el-row>
      </div>
      <div class="save-wrap">
        <el-button type="primary" class="save" @click="savepower">保存</el-button>
      </div>
      <!-- <div class="mode">
        <el-row :gutter="20">
          <el-col :span="10">WPS模式</el-col>
          <el-col :span="14">
            <el-select v-model="wps" clearable placeholder="请选择">
              <el-option
                v-for="item in wpsoptions"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
            <p class="note">通过 H 键进行 WPS 连接</p>
          </el-col>
        </el-row>
      </div> -->
    </div>
  </div>
</template>
<script>
import { get_wifi_info, set_wifi, set_wifi_power } from '@/api/article'
import { validPwd } from '@/utils/validate'
export default {
  data() {
    return {
      priority: '2',
      wifi: '1',
      wifi24g: '1',
      wifi5g: '1',
      wifiname: 'wifiabc',
      wifiname24g: 'wifiabc',
      wifiname5g: 'wifiabc5g',
      security: 'psk',
      security24g: 'psk2',
      security5g: 'none',
      securityoptions: [
        {
          value: 'none',
          label: '不加密'
        },
        {
          value: 'psk',
          label: 'WPA PSK模式'
        },
        {
          value: 'psk2',
          label: 'WPA2 PSK模式'
        },
        {
          value: 'psk-mixed',
          label: 'WPA/WPA2 PSK混合模式'
        }
      ],
      securityoptions24g: [
        {
          value: 'none',
          label: '不加密'
        },
        {
          value: 'psk',
          label: 'WPA PSK模式'
        },
        {
          value: 'psk2',
          label: 'WPA2 PSK模式'
        },
        {
          value: 'psk-mixed',
          label: 'WPA/WPA2 PSK混合模式'
        }
      ],
      securityoptions5g: [
        {
          value: 'none',
          label: '不加密'
        },
        {
          value: 'psk',
          label: 'WPA PSK模式'
        },
        {
          value: 'psk2',
          label: 'WPA2 PSK模式'
        },
        {
          value: 'psk-mixed',
          label: 'WPA/WPA2 PSK混合模式'
        }
      ],
      encryption: 'tkip',
      encryption24g: 'ccmp',
      encryption5g: 'tkip+ccmp',
      encryptionoptions: [
        {
          value: 'tkip',
          label: 'TKIP'
        },
        {
          value: 'ccmp',
          label: 'AES'
        },
        {
          value: 'tkip+ccmp',
          label: 'TKIP+AES'
        }
      ],
      encryptionoptions24g: [
        {
          value: 'tkip',
          label: 'TKIP'
        },
        {
          value: 'ccmp',
          label: 'AES'
        },
        {
          value: 'tkip+ccmp',
          label: 'TKIP+AES'
        }
      ],
      encryptionoptions5g: [
        {
          value: 'tkip',
          label: 'TKIP'
        },
        {
          value: 'ccmp',
          label: 'AES'
        },
        {
          value: 'tkip+ccmp',
          label: 'TKIP+AES'
        }
      ],
      pwd: '123456',
      pwd24g: '123456',
      pwd5g: '123456',
      power: '1',
      poweroptions: [
        {
          value: '1',
          label: '穿墙'
        },
        {
          value: '2',
          label: '一般'
        },
        {
          value: '3',
          label: '绿色'
        }
      ]
    }
  },
  created() {
    this.get_wifi_info()
  },
  activated() {

  },
  deactivated() {
  },
  methods: {
    validate() {
      if (this.wifi24g === '0') {
        if (!this.wifiname24g) {
          this.$message({
            message: '请输入2.4G wifi名字',
            type: 'error',
            duration: 5 * 1000
          })
          console.log('wifiname24g')
          return false
        }
        if (this.security24g !== 'none') {
          if (!validPwd(this.pwd24g)) {
            this.$message({
              message: '请输入正确的2.4G wifi密码（8-63个字符）',
              type: 'error',
              duration: 5 * 1000
            })
            console.log('pwd24g')
            return false
          }
        } else {
          this.encryption24g = ''
          this.pwd24g = ''
        }
      }
      if (this.wifi5g === '0') {
        if (!this.wifiname5g) {
          this.$message({
            message: '请输入5G wifi名字',
            type: 'error',
            duration: 5 * 1000
          })
          console.log('wifiname5g')
          return false
        }
        if (this.security5g !== 'none') {
          if (!validPwd(this.pwd5g)) {
            this.$message({
              message: '请输入正确的5G wifi密码（8-63个字符）',
              type: 'error',
              duration: 5 * 1000
            })
            console.log('pwd5g')
            return false
          }
        } else {
          this.encryption5g = ''
          this.pwd5g = ''
        }
        console.log('p666g')
      }
      console.log('p6888866g')
      return true
    },
    savewifi() {
      console.log('this.validate()', this.validate())
      if (this.validate()) {
        this.set_wifi()
      }
    },
    savepower() {
      this.set_wifi_power()
    },
    get_wifi_info() {
      get_wifi_info().then(response => {
        this.wifi24g = response.wifi_ap_info['2g_disabled']
        this.wifi5g = response.wifi_ap_info['5g_disabled']
        this.wifiname24g = response.wifi_ap_info['2g_ssid']
        this.wifiname5g = response.wifi_ap_info['5g_ssid']
        this.security24g = response.wifi_ap_info['2g_encmode']
        this.security5g = response.wifi_ap_info['5g_encmode']
        this.encryption24g = response.wifi_ap_info['2g_algo']
        this.encryption5g = response.wifi_ap_info['5g_algo']
        this.pwd24g = response.wifi_ap_info['2g_key']
        this.pwd5g = response.wifi_ap_info['5g_key']
        this.power = response.wifi_ap_info['txpower_mode']
      })
    },
    set_wifi() {
      const params = {
        '2g_disabled': this.wifi24g,
        '5g_disabled': this.wifi5g,
        '2g_ssid': this.wifiname24g,
        '5g_ssid': this.wifiname5g,
        '2g_encmode': this.security24g,
        '5g_encmode': this.security5g,
        '2g_algo': this.encryption24g,
        '5g_algo': this.encryption5g,
        '2g_key': this.pwd24g,
        '5g_key': this.pwd5g
      }
      set_wifi(params).then(response => {
        this.$message({
          message: '成功',
          type: 'success',
          duration: 5 * 1000
        })
      })
    },
    set_wifi_power() {
      const params = {
        'txpower_mode': this.power
      }
      set_wifi_power(params).then(response => {
        this.$message({
          message: '成功',
          type: 'success',
          duration: 5 * 1000
        })
      })
    },
    switchPriority() {
      if (this.priority === '2') {
        this.$confirm(
          'WiFi名称将合并为wifiabc，WiFi若断开，请重新连接。',
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
            center: true
          }
        )
          .then(() => {
            this.priority = '1'
          })
          .catch(() => {
          })
      } else {
        this.priority = '2'
      }
    },
    givetips() {
      if (this.power !== '1') {
        this.$confirm(
          '建议使用WiFi穿墙模式，上网体验更流畅',
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
            center: true
          }
        )
          .then(() => {
            this.power = '1'
          })
          .catch(() => {
          })
      }
    },
    switch24g() {
      if (this.wifi24g === '0') {
        this.$confirm(
          '若关闭此开关，连接到此 Wi-Fi 的设备将断开 请您确定是否关闭此开关？',
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
            center: true
          }
        )
          .then(() => {
            this.wifi24g = '1'
          })
          .catch(() => {
          })
      } else {
        this.wifi24g = '0'
      }
    },
    switch5g() {
      if (this.wifi5g === '0') {
        this.$confirm(
          '若关闭此开关，连接到此 Wi-Fi 的设备将断开 请您确定是否关闭此开关？',
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
            center: true
          }
        )
          .then(() => {
            this.wifi5g = '1'
          // this.$message({
          //   type: 'success',
          //   message: '删除成功!'
          // })
          })
          .catch(() => {
          // this.$message({
          //   type: 'info',
          //   message: '已取消删除'
          // })
          })
      } else {
        this.wifi5g = '0'
      }
    },
    switchwifi() {
      if (this.wifi === '0') {
        this.$confirm(
          '若关闭此开关，连接到此 Wi-Fi 的设备将断开 请您确定是否关闭此开关？',
          '提示',
          {
            confirmButtonText: '确定',
            cancelButtonText: '取消',
            type: 'warning',
            center: true
          }
        )
          .then(() => {
            this.wifi = '1'
          })
          .catch(() => {
          })
      } else {
        this.wifi = '0'
      }
    }

  }
}
</script>
<style scoped lang='scss'>
.wifi-setting {
  min-height: 100%;
  background: rgba(255, 255, 255, 1);
  box-shadow: 0px 20px 40px 0px rgba(48, 56, 73, 0.15);
  border-radius: 20px;
  .status {
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .tips {
    display: inline-block;
    margin-left: 16px;
    margin-right: 30px;
    p:first-child {
      font-size: 24px;
      font-weight: 800;
      margin: 0;
    }
    p:last-child {
      margin: 5px 0 0;
    }
  }
  ::v-deep .el-col-10 {
    text-align: right;
    height: 36px;
    line-height: 36px;
  }
  ::v-deep .el-col-14 {
    text-align: left;
  }
}
.wifi-wrap {
  width: 800px;
  margin: 0 auto;
  text-align: center;
  padding-top: 24px;
  padding-bottom: 24px;
}
.input-wrap,
.select-wrap {
  margin-top: 22px;
}
.priority,
.wifi {
  margin-top: 14px;
  ::v-deep .el-col-10 {
    margin-top: -6px;
  }
}
.mode {
  margin-top: 22px;
}

.note {
  font-size: 12px;
  color: rgba(48, 56, 73, 1);
  margin: 5px 0;
}
.note-require {
  color: rgba(83, 170, 254, 1);
}
.save-wrap {
  margin-left: 26%;
}
.save {
  margin-top: 20px;
}
.switch {
  background: transparent;
  width: 40px;
  height: 30px;
  position: absolute;
  z-index: 9;
}
.note {
  line-height: 15px;
  font-size: 12px;
  color: rgba(48, 56, 73, 1);
  margin: 5px 0;
}
.el-icon-warning{
  color:red;
  font-size: 18px;
  margin-right: 5px;
}
</style>
