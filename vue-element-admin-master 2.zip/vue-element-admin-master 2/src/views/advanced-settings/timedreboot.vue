<template>
  <div class="timedreboot">
    <div class="timed-wrap">
      <p class="txt title">定时重启设备</p>
      <p class="tips">建议开启，定时重启设备，设备总是处在最优化状态，有利于设备稳定运行。</p>
      <div>
        <div class="mode">
          <el-row :gutter="20">
            <el-col :span="8" class="name">
              定时重启设备
            </el-col>
            <el-col :span="16" class="content">
              <div class="switch" />
              <el-switch v-model="timed_reboot_switch" active-value="1" inactive-value="0" />
            </el-col>
          </el-row>
        </div>
        <div v-if="timed_reboot_switch==='1'" class="mode">
          <el-row :gutter="20">
            <el-col :span="8">
              定时重启时间
            </el-col>
            <el-col :span="16">
              <el-select v-model="reboot_time_hour" clearable placeholder="请选择" class="reboot-select">
                <el-option
                  v-for="item in timeHouroptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
              <el-select v-model="reboot_time_min" clearable placeholder="请选择" class="reboot-select">
                <el-option
                  v-for="item in timeMinoptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select></el-col>
          </el-row>
        </div>
      </div>

      <div class="save-wrap">
        <el-button type="primary" class="save" @click="save">保存</el-button>
      </div>
    </div>
  </div>
</template>
<script>
import { get_timed_reboot_info, set_timed_reboot } from '@/api/article'
export default {
  data() {
    return {
      timed_reboot_switch: '1',
      reboot_time_hour: '',
      timeHouroptions: [],
      timeMinoptions: [],
      reboot_time_min: ''

    }
  },
  created() {
    for (let i = 0; i < 24; i++) {
      this.timeHouroptions.push({
        value: i < 10 ? ('0' + i) : i,
        label: i < 10 ? ('0' + i) : i
      })
    }
    for (let i = 0; i < 60; i++) {
      this.timeMinoptions.push({
        value: i < 10 ? ('0' + i) : i,
        label: i < 10 ? ('0' + i) : i
      })
    }
    this.get_timed_reboot_info()
  },
  activated() {},
  deactivated() {},
  methods: {
    save() {
      const params = {
        timed_reboot_switch: this.timed_reboot_switch,
        reboot_time: this.reboot_time_hour + ':' + this.reboot_time_min
      }
      set_timed_reboot(params).then(response => {
        this.$message({
          message: '成功',
          type: 'success',
          duration: 2 * 1000
        })
      })
    },
    get_timed_reboot_info() {
      get_timed_reboot_info().then(response => {
        this.timed_reboot_switch = response.timed_reboot_info.timed_reboot_switch
        this.reboot_time_hour = response.timed_reboot_info.reboot_time.split(':')[0]
        this.reboot_time_min = response.timed_reboot_info.reboot_time.split(':')[1]
      })
    }
  }
}
</script>
<style scoped lang='scss'>
.timedreboot {
  width: 100%;
  min-height: 100%;
  background: rgba(255, 255, 255, 1);
  box-shadow: 0px 20px 40px 0px rgba(48, 56, 73, 0.15);
  border-radius: 20px;
  .txt,
  .tips{
    text-align: left;
  }
  .title {
    font-size: 20px;
    font-weight: 600;
    margin-bottom: 10px;
  }
  .tips {
    margin-top: 10px;
  }
  ::v-deep .el-col-8 {
    text-align: right;
    height: 36px;
    line-height: 36px;
  }
  ::v-deep .el-col-16 {
    text-align: left;
    height: 36px;
    line-height: 36px;
  }

}
.timed-wrap {
  width: 620px;
  margin: 0 auto;
  text-align: center;
  padding-top: 24px;
  padding-bottom: 24px;
}
::v-deep .reboot-select .el-input{
  width: 154px;
  margin-right: 10px;
}

.input-wrap,
.select-wrap {
  margin-top: 22px;
}

.mode {
  margin-top: 22px;
}

.save-wrap {
  // margin-left: 26%;
}
.save {
  margin-top: 20px;
}
</style>
