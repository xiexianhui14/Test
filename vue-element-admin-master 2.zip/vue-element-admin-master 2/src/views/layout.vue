<template>
  <el-container>
    <el-header height="80px">
      <el-row>
        <!-- <el-col :span="21">
          <el-menu
            :default-active="defaultActive"
            class="el-menu-demo"
            mode="horizontal"
            text-color="#fff"
            active-text-color="#4BA9FD"
            router
            @select="handleSelect"
          >
            <img src="../assets/login/logo.png" width="152" height="45" alt="logo" class="logo">
            <el-menu-item index="layout">
              <img
                v-if="activeKey==='layout'"
                src="../assets/home/top_b.png"
                width="17"
                height="17"
              >
              <img v-else src="../assets/home/top_w.png" width="17" height="17">
              首页
            </el-menu-item>
            <el-menu-item index="internetsetting">
              <img
                v-if="activeKey==='internetsetting'"
                src="../assets/home/internet_b.png"
                width="17"
                height="17"
              >
              <img v-else src="../assets/home/internet_w.png" width="17" height="17"> 上网设置
            </el-menu-item>
            <el-menu-item index="wifisetting">
              <img
                v-if="activeKey==='wifisetting'"
                src="../assets/home/wifi_b.png"
                width="18"
                height="14"
              >
              <img v-else src="../assets/home/wifi.png" width="18" height="14">
              WiFi设置
            </el-menu-item>
            <el-menu-item index="terminalsetting">
              <img
                v-if="activeKey==='terminalsetting'"
                src="../assets/home/terminal_b.png"
                width="17"
                height="17"
              >
              <img v-else src="../assets/home/terminal_w.png" width="17" height="17">
              终端管理
            </el-menu-item>
            <el-menu-item index="systeminfo" :class="activeKey==='systeminfo'? 'is-active': ''">
              <img
                v-if="activeKey==='systeminfo'"
                src="../assets/home/setting_b.png"
                width="19"
                height="17"
              >
              <img v-else src="../assets/home/setting_w.png" width="19" height="17">
              高级设置
            </el-menu-item>
          </el-menu>
        </el-col> -->
        <el-col :span="3"
                class="info-wrap">
          <!-- <div class="basic--circle">
            <el-avatar :size="45" :src="circleUrl" />
            <el-avatar :size="45" :src="circleUrl" />
            <el-avatar :size="45" :src="circleUrl" />
          </div>-->
          <div class="logout"
               @click="logout">退出</div>
          <!-- <el-dropdown>
            <span class="el-dropdown-link">
              退出
              <i class="el-icon-arrow-down el-icon--right" />
            </span>
            <el-dropdown-menu slot="dropdown">
              <el-dropdown-item>退出</el-dropdown-item>
              <el-dropdown-item>多吃饭不减肥</el-dropdown-item>
            </el-dropdown-menu>
          </el-dropdown>-->
        </el-col>
      </el-row>
    </el-header>
    <el-main v-if="judgehorizontal(activeKey)">
      <keep-alive>
        <router-view />
      </keep-alive>
    </el-main>
    <el-container v-else>
      <el-aside width="300px">
        <el-menu :default-active="defaultActive"
                 class="el-menu-vertical"
                 text-color="#2F3749"
                 active-text-color="#4BA9FD"
                 router
                 @open="handleOpen"
                 @close="handleClose">
          <el-menu-item index="systeminfo">
            <span slot="title">系统信息</span>
          </el-menu-item>
          <el-menu-item index="wifiadvancedsetting">
            <span slot="title">无线设置</span>
          </el-menu-item>
          <el-menu-item index="LANsetting">
            <span slot="title">局域网设置</span>
          </el-menu-item>
          <el-menu-item index="ipv6">
            <span slot="title">IPv6</span>
          </el-menu-item>
          <el-menu-item index="selectedapplication">
            <span slot="title">精选应用</span>
          </el-menu-item>
          <el-submenu index="changepwd"
                      class="system">
            <template slot="title"
                      @click="opensubmenu">
              <span>系统设置</span>
            </template>
            <el-menu-item index="changepwd">修改管理密码</el-menu-item>
            <el-menu-item index="timesetting">时间设置</el-menu-item>
            <el-menu-item index="ledsetting">LED设置</el-menu-item>
            <el-menu-item index="timedreboot">定时重启</el-menu-item>
            <el-menu-item index="systemlog">系统日志</el-menu-item>
            <el-menu-item index="backupandrecover">备份与恢复</el-menu-item>
            <el-menu-item index="rebootdevice">重启设备</el-menu-item>
          </el-submenu>
          <el-menu-item index="softwareupdate">
            <span slot="title">软件升级</span>
          </el-menu-item>
        </el-menu>
      </el-aside>
      <el-main class="advanced-wrap">
        <keep-alive>
          <router-view />
        </keep-alive>
      </el-main>
    </el-container>
  </el-container>
</template>
<script>
import { logout } from '@/api/user'
export default {
  data () {
    return {
      circleUrl:
        'https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png',
      activeKey: this.$route.path.split('/')[1]
    }
  },
  computed: {
    defaultActive: function () {
      return this.$route.path.replace('/', '')
    }
  },
  created () {
    if (!this.judgehorizontal(this.activeKey)) {
      this.activeKey = 'systeminfo'
    }
  },
  methods: {
    handleSelect (key, keyPath) {
      this.activeKey = key
      console.log('abc', keyPath)
      console.log('cde', this.$route.path)
    },
    judgehorizontal (activeKey) {
      if (
        activeKey === 'layout' ||
        activeKey === 'internetsetting' ||
        activeKey === 'terminalsetting' ||
        activeKey === 'wifisetting'
      ) {
        return true
      } else {
        return false
      }
    },
    opensubmenu () {
      console.log('222222')
    },
    handleOpen () {
      console.log('55555')
    },
    handleClose () {

    },
    logout () {
      logout().then(response => {
        localStorage.removeItem('token')
        this.$router.push({ path: '/login' })
      })
    }
  }
}
</script>
<style scoped lang='scss'>
.el-container {
  overflow: hidden;
  height: 100%;
  background: rgba(244, 245, 248, 1);
}
.el-header {
  padding: 0 40px;
  background: linear-gradient(
    90deg,
    rgba(19, 230, 173, 1) 0%,
    rgba(61, 147, 242, 1) 100%
  );
  color: #333;
  text-align: center;
}
.el-main {
  overflow-y: scroll;
  color: #333;
  height: calc(100% - 80px);
  padding: 20px 40px;
}
.advanced-wrap {
  height: 100%;
  overflow-y: scroll;
  padding: 20px 40px;
}
.el-menu {
  border: none;
  background: transparent;
}
.logo {
  float: left;
  margin-top: 17px;
  margin-right: 128px;
  &:focus {
    outline: none;
  }
}
.basic--circle {
  margin-bottom: -19px;
  display: inline-block;
}
.info-wrap {
  height: 80px;
  line-height: 80px;
  text-align: right;
}
.el-dropdown {
  height: 45px;
  color: #fff;
  font-size: 16px;
}
.el-avatar--circle {
  margin-bottom: -19px;
  margin-right: 17px;
}
.el-menu--horizontal > .el-menu-item {
  height: 80px;
  line-height: 80px;
  border-bottom: none;
  img {
    margin-bottom: 6px;
  }
}
.el-menu-item:hover,
.el-menu-item:focus {
  background: transparent;
}
.el-menu--horizontal > .el-menu-item:not(.is-disabled):hover,
.el-menu--horizontal > .el-menu-item:not(.is-disabled):focus {
  background: transparent;
}
.el-menu--horizontal > .el-menu-item.is-active {
  background: #fff !important;
  border: none;
}
.el-menu-item.is-active {
  color: #4ba9fd !important;
}
.el-row {
  height: 100%;
}
.el-col {
  height: 100%;
}
.logout {
  display: inline-block;
  cursor: pointer;
  color: #fff;
  font-size: 18px;
}

.el-menu-vertical {
  .el-menu-item.is-active {
    background: rgba(75, 169, 253, 0.15);
    border-right: 5px solid #4ba9fd;
  }
  .el-menu-item {
    padding-left: 40px !important;
  }
  .system {
    ::v-deep li::before {
      content: "\02022";
    }
    .el-menu-item {
      padding-left: 60px !important;
    }
    .el-menu-item.is-active {
      background: none;
      border-right: none;
    }
  }
  ::v-deep .el-submenu.is-active .el-submenu__title {
    background: rgba(75, 169, 253, 0.15);
    border-right: 5px solid #4ba9fd;
    color: #4ba9fd !important;
  }
  ::v-deep .el-submenu__title {
    font-size: 18px;
    -webkit-transition: border-color 0s, background-color 0s, color 0s;
    transition: border-color 0s, background-color 0s, color 0s;
  }
  ::v-deep .el-submenu__title:hover,
  .el-submenu__title:focus {
    background-color: #fff;
  }
}
.el-menu-item {
  font-size: 18px;
  -webkit-transition: border-color 0s, background-color 0s, color 0s;
  transition: border-color 0s, background-color 0s, color 0s;
}
::v-deep .el-submenu__title {
  padding-left: 40px !important;
}
</style>
