<template>
  <div class="internet-setting">
    <div class="internet-wrap">
      <div class="status">
        <div v-if="!isreconnect">
          <i :class="net_link==='1'? 'el-icon-circle-check': 'el-icon-warning-outline'" />
          <div v-if="net_link==='1'" class="tips">
            <p>已成功连接到互联网</p>
          </div>
          <div v-else class="tips">
            <p>路由器未连接互联网</p>
            <p>未检测到入户网线，请检查网线</p>
          </div>
        </div>
        <div v-if="isreconnect">
          <i class="el-icon-loading" />
          <p class="wait">正在连接互联网，请耐心等待...</p>
        </div>
        <el-button type="primary" @click="reconnect">重新连接</el-button>
      </div>
      <div class="detect ">
        <el-row :gutter="20">
          <el-col :span="10">自动识别上网方式</el-col>
          <el-col :span="14">
            <el-switch v-model="value1" />
            <p class="note">开启后网线接入时将自动识别上网方式，组网固定后，建议关闭</p>
          </el-col>
        </el-row>
      </div>
      <el-form
        ref="internetForm"
        :model="internetForm"
        :rules="internetRules"
        class="internet-form"
        autocomplete="on"
        label-position="left"
      >
        <el-form-item class="select-wrap" prop="method">
          <el-row :gutter="20">
            <el-col :span="10">上网方式</el-col>
            <el-col :span="14">
              <el-select v-model="method" clearable placeholder="请选择">
                <el-option
                  v-for="item in methodoptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-col>
          </el-row>
        </el-form-item>
        <!-- 宽带帐号上网（PPPoE）start -->
        <div v-if="method==='pppoe'">
          <el-form-item class="input-wrap" prop="username">
            <el-row :gutter="20">
              <el-col :span="10">宽带账号</el-col>
              <el-col :span="14">
                <el-input v-model="internetForm.username" placeholder="请输入内容" />
              </el-col>
            </el-row>
          </el-form-item>
          <el-form-item class="input-wrap" prop="password">
            <el-row :gutter="20">
              <el-col :span="10">宽带密码</el-col>
              <el-col :span="14">
                <el-input v-model="internetForm.password" placeholder="请输入密码" show-password />
              </el-col>
            </el-row>
          </el-form-item>
        <!-- <div class="input-wrap">
          <el-row :gutter="20">
            <el-col :span="10">服务名</el-col>
            <el-col :span="14">
              <el-input v-model="input" placeholder="请输入内容" />
            </el-col>
          </el-row>
        </div>
        <div class="select-wrap">
          <el-row :gutter="20">
            <el-col :span="10">拨号方式</el-col>
            <el-col :span="14">
              <el-select v-model="dialmode" clearable placeholder="请选择">
                <el-option
                  v-for="item in dialmodeoptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-col>
          </el-row>
        </div> -->
        </div>

        <!-- 宽带帐号上网（PPPoE）end -->
        <!-- 手动输入IP（静态IP) start -->
        <div v-if="method==='static'">

          <el-form-item class="input-wrap" prop="ipaddr">
            <el-row :gutter="20">
              <el-col :span="10">IP地址</el-col>
              <el-col :span="14">
                <el-input v-model="internetForm.ipaddr" placeholder="请输入内容" />
              </el-col>
            </el-row>
          </el-form-item>
          <el-form-item class="input-wrap" prop="netmask">
            <el-row :gutter="20">
              <el-col :span="10">子网掩码</el-col>
              <el-col :span="14">
                <el-input v-model="internetForm.netmask" placeholder="请输入内容" />
              </el-col>
            </el-row>
          </el-form-item>
          <el-form-item class="input-wrap" prop="gateway">
            <el-row :gutter="20">
              <el-col :span="10">默认网关</el-col>
              <el-col :span="14">
                <el-input v-model="internetForm.gateway" placeholder="请输入内容" />
              </el-col>
            </el-row>
          </el-form-item>
          <el-form-item class="input-wrap" prop="dns1">
            <el-row :gutter="20">
              <el-col :span="10">首选DNS服务器</el-col>
              <el-col :span="14">
                <el-input v-model="internetForm.dns1" placeholder="请输入内容" />
              </el-col>
            </el-row>
          </el-form-item>
          <el-form-item class="input-wrap" prop="dns2">
            <el-row :gutter="20">
              <el-col :span="10">备用DNS服务器</el-col>
              <el-col :span="14">
                <el-input v-model="internetForm.dns2" placeholder="请输入内容" />
                <span class="note-require">（可不填）</span>
              </el-col>
            </el-row>
          </el-form-item>
        </div>

        <!-- 手动输入IP（静态IP) end -->
        <el-form-item class="input-wrap" prop="mtu">
          <el-row :gutter="20">
            <el-col :span="10">最大发送单元（MTU）</el-col>
            <el-col :span="14">
              <el-input-number v-model="internetForm.mtu" :controls="false" :min="0" :max="1500" class="mini" placeholder="请输入内容" />
            </el-col>
          </el-row>
        </el-form-item>
        <el-form-item class="select-wrap" prop="macclone">
          <el-row :gutter="20">
            <el-col :span="10">MAC克隆</el-col>
            <el-col :span="14">
              <el-select v-model="macclone" clearable placeholder="请选择">
                <el-option
                  v-for="item in maccloneoptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-col>
          </el-row>
        </el-form-item>
        <el-form-item v-if="macclone==='2'" class="input-wrap" prop="macaddr">
          <el-row :gutter="20">
            <el-col :span="10">MAC 地址</el-col>
            <el-col :span="14">
              <el-input v-model="internetForm.macaddr" placeholder="请输入内容" />
              <p class="note">MAC 地址格式：XX-XX-XX-XX-XX-XX</p>
              <p class="note">或 XX:XX:XX:XX:XX:XX </p>
            </el-col>
          </el-row>
        </el-form-item>
        <div v-if="method!=='static'">
          <div class="dns">
            <el-row :gutter="20">
              <el-col :span="10">静态DNS</el-col>
              <el-col :span="14">
                <el-switch v-model="internetForm.peerdns" active-value="0" inactive-value="1" />
              </el-col>
            </el-row>
          </div>
          <div v-if="internetForm.peerdns==='0'" class="dns-wrap">
            <el-form-item class="input-wrap" prop="otherdns1">
              <el-row :gutter="20">
                <el-col :span="10">首选DNS服务器</el-col>
                <el-col :span="14">
                  <el-input v-model="internetForm.dns1" placeholder="请输入内容" />
                </el-col>
              </el-row>
            </el-form-item>
            <el-form-item class="input-wrap" prop="otherdns2">
              <el-row :gutter="20">
                <el-col :span="10">备用DNS服务器</el-col>
                <el-col :span="14">
                  <el-input v-model="internetForm.dns2" placeholder="请输入内容" />
                  <span class="note-require">（可不填）</span>
                </el-col>
              </el-row>
            </el-form-item>
          </div>
        </div>

        <div class="save-wrap">
          <el-button type="primary" class="save" @click="saveData">保存</el-button>
        </div>
      </el-form>
    </div>

  </div>
</template>
<script>
import { get_wan_status, get_wan_info, reconnect_wan, set_wan } from '@/api/article'
import { validUsername, validIP, validMAC } from '@/utils/validate'
import { Message } from 'element-ui'
export default {
  data() {
    const validateUsername = (rule, value, callback) => {
      if (!validUsername(value)) {
        callback(new Error('Please enter the correct user name'))
      } else {
        callback()
      }
    }

    const validatePassword = (rule, value, callback) => {
      if (value.length < 6) {
        callback(new Error('The password can not be less than 6 digits'))
      } else {
        callback()
      }
    }
    const validateIP = (rule, value, callback) => {
      if (!validIP(value)) {
        callback(new Error('Please enter correct format'))
      } else {
        callback()
      }
    }
    const validateMAC = (rule, value, callback) => {
      if (!validMAC(value)) {
        console.log('value', value)
        callback(new Error('Please enter correct format'))
      } else {
        callback()
      }
    }
    const validateMTU = (rule, value, callback) => {
      if (value < 0 || value > 1500 || value == '') {
        console.log('value', value)
        callback(new Error('value must between 0 to 1500'))
      } else {
        callback()
      }
    }
    return {
      internetForm: {
        proto: '',
        username: '',
        password: '',
        ipaddr: '',
        netmask: '',
        dns2: '',
        dns1: '',
        peerdns: '',
        mtu: '200',
        macclone_type: '',
        macaddr: ''
      },
      internetRules: {
        username: [
          { required: true, trigger: 'blur', validator: validateUsername }
        ],
        password: [
          { required: true, trigger: 'blur', validator: validatePassword }
        ],
        ipaddr: [
          { required: true, trigger: 'blur', validator: validateIP }
        ],
        netmask: [
          { required: true, trigger: 'blur', validator: validateIP }
        ],
        gateway: [
          { required: true, trigger: 'blur', validator: validateIP }
        ],
        dns1: [
          { required: true, trigger: 'blur', validator: validateIP }
        ],
        otherdns1: [
          { required: true, trigger: 'blur', validator: validateIP }
        ],
        macaddr: [
          { required: true, trigger: 'blur', validator: validateMAC }
        ],
        mtu: [
          { required: true, trigger: 'blur', validator: validateMTU }
        ]

      },
      value1: '',
      isreconnect: false,
      net_link: '0',
      methodoptions: [
        {
          value: 'pppoe',
          label: '宽带帐号上网（PPPOE）'
        },
        {
          value: 'dhcp',
          label: '自动获取IP（DHCP）'
        },
        {
          value: 'static',
          label: '手动输入IP（静态IP）'
        }
      ],
      maccloneoptions: [
        {
          value: '0',
          label: '不使用MAC克隆'
        },
        {
          value: '1',
          label: '使用您电脑的MAC地址'
        },
        {
          value: '2',
          label: '手动输入MAC地址'
        }
      ],
      method: 'pppoe',
      macclone: '0'
    }
  },
  created() {
    this.getWanStatus()
    this.getWanInfo()
  },
  activated() {
    this.timer = setInterval(this.getWanStatus, 5000)
  },
  deactivated() {
    clearInterval(this.timer)
  },
  methods: {
    getWanStatus() {
      get_wan_status().then(response => {
        console.log('response', response)
        this.net_link = response.wan_status.net_link
      })
    },
    getWanInfo() {
      get_wan_info().then(response => {
        console.log('response', response)
        this.method = response.wan_config.proto
        this.macclone = response.mac_config.macclone_type
        // this.wan_config = response.wan_config

        for (var a in response.wan_config) {
          this.internetForm[a] = response.wan_config[a]
        }

        for (var it in response.mac_config) {
          this.internetForm[it] = response.mac_config[it]
        }

        console.log('this.internetForm', this.internetForm)
      })
    },
    reconnect() {
      this.isreconnect = true
      reconnect_wan().then(response => {
        Message({
          message: '成功',
          type: 'success',
          duration: 5 * 1000
        })
        this.isreconnect = false
      })
    },
    saveData() {
      this.internetForm.proto = this.method
      this.internetForm.macclone_type = this.macclone
      const reg = /^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$/
      this.$refs.internetForm.validate(valid => {
        if (valid) {
          if (this.internetForm.dns2 && !(reg.test(this.internetForm.dns2))) {
            console.log('kkk')
            Message({
              message: 'Please enter correct format dns',
              type: 'error',
              duration: 5 * 1000
            })
          }
          if (this.internetForm.otherdns2 && !(reg.test(this.internetForm.otherdns2))) {
            console.log('kkk')
            Message({
              message: 'Please enter correct format dns',
              type: 'error',
              duration: 5 * 1000
            })
          }
          console.log('this.internetForm11', this.internetForm)
          set_wan(this.internetForm).then(response => {
            Message({
              message: '成功',
              type: 'success',
              duration: 5 * 1000
            })
          })
        } else {
          console.log('error submit!!')
          return false
        }
      })
      // const params = this.wan_config.concat(this.macclone)
    }

  }
}
</script>
<style scoped lang='scss'>
$dark_gray:#889aa4;
.internet-setting {
  min-height: 100%;
  background: rgba(255, 255, 255, 1);
  box-shadow: 0px 20px 40px 0px rgba(48, 56, 73, 0.15);
  border-radius: 20px;
  .status {
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .tips {
    display: inline-block;
    margin-left: 16px;
    margin-right: 30px;
    p:first-child {
      font-size: 24px;
      font-weight: 800;
      margin: 0;
    }
    p:last-child {
      margin: 5px 0 0;
    }
  }
  ::v-deep .el-col-10 {
    text-align: right;
    height: 36px;
    line-height: 36px;
  }
  ::v-deep .el-col-14 {
    text-align: left;
  }
  ::v-deep .el-input-number.is-without-controls .el-input__inner{
    text-align: left;
  }
}
.el-icon-circle-check{
  font-size: 48px;
  color: #13e6ad;
}
.el-icon-warning-outline {
  font-size: 48px;
  color: #3d93f2;
}
.internet-wrap {
  width: 800px;
  margin: 0 auto;
  padding-top: 60px;
  padding-bottom: 24px;
  text-align: center;
}
.input-wrap,
.select-wrap,
.dns {
  margin-top: 14px;
}
.detect {
  margin-top: 50px;
  ::v-deep .el-col-10 {
    margin-top: -6px;
  }
}
.wait{
  float: right;
  padding-left: 10px;
    padding-right: 10px;
}
.el-icon-loading{
  font-size: 40px;
}
.dns {
  ::v-deep .el-col-10 {
    margin-top: -6px;
  }
}
::v-deep .el-form-item__error{
 left:45%;
}
.note {
  line-height: 15px;
  font-size: 12px;
  color: rgba(48, 56, 73, 1);
  margin: 5px 0;
}
.note-require {
  color: rgba(83, 170, 254, 1);
}
.save-wrap {
  margin-left: 26%;
}
.save {
  margin-top: 20px;
}

</style>
