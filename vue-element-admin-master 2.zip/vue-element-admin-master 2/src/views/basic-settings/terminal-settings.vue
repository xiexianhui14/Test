<template>
  <div class="terminal-setting">
    <p class="title">主设备</p>
    <div class="head">
      <el-row>
        <el-col :span="2">设备头像</el-col>
        <el-col :span="3">设备名称</el-col>
        <el-col :span="3">IP</el-col>
        <el-col :span="3">MAC地址</el-col>
        <el-col :span="5">网速</el-col>
        <el-col :span="6">修改限速</el-col>
        <el-col :span="2">允许上网</el-col>
      </el-row>
    </div>
    <div class="content">
      <el-row type="flex" align="middle">
        <el-col :span="2">
          <el-avatar :src="circleUrl" style="margin-left:14px" />
        </el-col>
        <el-col :span="3">
          <span v-show="!editName" @click="editName=true">Unknown</span>
          <el-input
            v-show="editName"
            v-model="deviceName"
            placeholder="请输入内容"
            clearable
            @blur="editName=false"
          />
        </el-col>
        <el-col :span="3">192.168.71.234</el-col>
        <el-col :span="3">90:94:97:1D:40:02</el-col>
        <el-col :span="5">
          9.0KB/S
          <img src="../../assets/terminal/up.png" class="speed">
          97.0KB/S
          <img src="../../assets/terminal/down.png" class="speed">
        </el-col>
        <el-col :span="6">
          <span v-show="!editUp" @click="editUp=true">
            无限速
            <img src="../../assets/terminal/up.png" class="speed">
          </span>
          <el-input
            v-show="editUp"
            v-model="upSpeed"
            placeholder="上传速度"
            clearable
            @blur="editUp=false"
          />
          <span v-show="!editDown" @click="editDown=true">
            无限速
            <img src="../../assets/terminal/down.png" class="speed">
          </span>

          <el-input
            v-show="editDown"
            v-model="downSpeed"
            placeholder="下载速度"
            clearable
            @blur="editDown=false"
          />
        </el-col>
        <el-col :span="2">
          <el-switch v-model="limit" active-value="1" inactive-value="2" />
        </el-col>
      </el-row>
    </div>
  </div>
</template>
<script>
export default {
  data() {
    return {
      limit: '2',
      circleUrl: 'https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png',
      deviceName: 'Unknown',
      upSpeed: '',
      downSpeed: '',
      editName: false,
      editUp: false,
      editDown: false
    }
  },
  methods: {

  }
}
</script>
<style scoped lang='scss'>
.terminal-setting {
  min-height: 100%;
  padding: 20px 40px;
  background: rgba(255, 255, 255, 1);
  box-shadow: 0px 20px 40px 0px rgba(48, 56, 73, 0.15);
  border-radius: 20px;
  .title{
    font-size: 24px;
  }
  .content{
    margin-top: 20px;
    ::v-deep .el-input{
      width: 140px;
    }
  }
  .speed{
    height: 16px;
    width: 16px;
  }
}
</style>
