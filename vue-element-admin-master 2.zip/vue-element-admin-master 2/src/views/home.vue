<template>
  <div class="home">
    <el-row :gutter="50">
      <el-col :span="12">
        <p class="title">网络拓扑</p>
        <div class="grid-content bg-purple wifi-right">
          <div class="internet">Internet</div>
          <div class="v-line" />
          <div class="wan">
            <img src="../assets/home/x.png"
                 width="12"
                 height="12">
          </div>
          <div class="wan-txt">WAN口无网线连接</div>
          <div class="v-line" />
          <div class="router">
            <img src="../assets/home/router.png"
                 width="64"
                 height="52">
            <div class="router-num">1</div>
          </div>
          <div class="router-txt">TL-WDR7650 千兆易展版</div>
          <div class="v-line" />
          <div class="h-line" />
          <div class="wrap">
            <div class="router-item">
              <div class="v-line" />

              <div class="router">
                <img src="../assets/home/hardware.png"
                     width="64"
                     height="52">
                <div class="router-num">1</div>
              </div>
              <div class="router-txt">TL-WDR7650 千兆易展版</div>
            </div>
            <div class="router-item">
              <div class="v-line" />

              <div class="router">
                <img src="../assets/home/hardware.png"
                     width="64"
                     height="52">
                <div class="router-num">1</div>
              </div>
              <div class="router-txt">TL-WDR7650 千兆易展版</div>
            </div>
            <div class="router-item">
              <div class="v-line" />

              <div class="router">
                <img src="../assets/home/hardware.png"
                     width="64"
                     height="52">
              </div>
              <div class="router-txt">匿名主机</div>
            </div>
          </div>
        </div>
      </el-col>
      <el-col :span="12">
        <el-row :gutter="50">
          <el-col :span="12">
            <p class="title">在线设备</p>
            <div class="online-device">
              <el-row>
                <el-col :span="12"
                        class="info-txt">
                  <p class="info-content">在线设备</p>
                  <p class="device-number">
                    <span class="num">{{ device_info.client_cnt }}</span>台
                  </p>
                </el-col>
                <el-col :span="12"
                        class="signal-wrap">
                  <div class="signal">
                    <img src="../assets/home/signal.png"
                         width="43"
                         height="51">
                  </div>
                </el-col>
              </el-row>
            </div>
            <p class="title">WiFi信息</p>
            <div class="wifi-info">
              <div class="signal-chanel">
                <p>2.4G</p>
                <p>SSID：{{ wifi_info['2g_ssid'] }}</p>
                <p>信道：{{ wifi_info['2g_channel'] }}</p>
              </div>
              <div class="signal-chanel">
                <p>5G</p>
                <p>SSID：{{ wifi_info['5g_ssid'] }}</p>
                <p>信道：{{ wifi_info['2g_channel'] }}</p>
              </div>
            </div>
            <p class="title">WAN口信息</p>
            <div class="wan-info">
              <p>IP：{{ wan_info.ip_addr }}</p>
              <p>MAC：{{ wan_info.mac_addr }}</p>
            </div>
          </el-col>
          <el-col :span="12">
            <p class="title">路由器运行时间</p>
            <div class="runtime">
              <el-row>
                <el-col :span="12"
                        class="info-txt">
                  <p class="info-content">路由器运行时间</p>
                  <p class="device-number">
                    {{ runtime }}
                  </p>
                </el-col>
                <el-col :span="12"
                        class="signal-wrap">
                  <div class="signal">
                    <img src="../assets/home/time.png"
                         width="60"
                         height="60">
                  </div>
                </el-col>
              </el-row>
            </div>
            <p class="title">网速</p>
            <div class="speed">
              <div>
                <div class="speed-num top">
                  <i class="el-icon-top" />
                  <div class="top-num">{{ wan_info.tx_rate }}</div>
                </div>
                <div>上传 </div>
              </div>
              <div>
                <div class="speed-num">
                  {{ wan_info.rx_rate }}
                  <i class="el-icon-bottom"
                     style="font-size:20px" />
                </div>
                <div>下载 </div>
              </div>
            </div>
            <p class="title">软件版本及公司信息</p>
            <div class="software-info">
              <p>软件版本：{{ device_info.sw_ver }}</p>
              <p>{{ device_info.vendor }}</p>
            </div>
            <p class="title">重启路由器</p>
            <div class="reboot"
                 @click="reboot">
              <img src="../assets/home/reboot.png"
                   width="50"
                   height="50">
            </div>
          </el-col>
        </el-row>
      </el-col>
    </el-row>
    <el-dialog title="设备重启"
               :visible.sync="centerDialogVisible"
               width="30%"
               :show-close="false"
               :close-on-click-modal="false"
               :close-on-press-escape="false"
               center>
      <i class="el-icon-loading" />
      <span slot="footer"
            class="dialog-footer">
        设备正在重启，请稍后...{{ reboottime }}
      </span>
    </el-dialog>
  </div>
</template>
<script>
import { home, set_reboot } from '@/api/article'

export default {
  data () {
    return {
      wan_info: {},
      wifi_info: {},
      device_info: {},
      runtime: '',
      timer: '',
      circleUrl:
        'https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png',
      centerDialogVisible: false,
      time: 0,
      reboottime: ''
    }
  },
  created () {
    this.getdata()
  },

  activated () {
    this.timer = setInterval(this.getdata, 5000)
  },
  deactivated () {
    clearInterval(this.timer)
  },
  methods: {
    addtime () {
      const that = this
      console.log('this.time', this.time)
      const timer = setInterval(function () {
        console.log('this.time', that.time)
        if (parseInt(that.time) < 70) {
          console.log('aadfafeee')
          that.time += 1
          that.reboottime = that.secondsFormatmin(that.time)
          console.log('this.time', that.time)
        } else {
          localStorage.removeItem('token')
          that.$router.push({ path: '/login' })
          console.log('agdfhdhadfaf')
          clearInterval(timer)
        }
      }, 1000)
    },
    getdata () {
      // home().then(response => {
      //   console.log('response', response)
      //   this.wan_info = response.wan_info
      //   this.wifi_info = response.wifi_info
      //   this.device_info = response.device_info
      //   this.runtime = this.secondsFormat(response.device_info.uptime)
      // })
    },
    rebootrouter () {
      const params = {
        reboot: 1
      }
      set_reboot(params).then(response => {
        clearInterval(this.timer)
        this.centerDialogVisible = true
        this.addtime()
      })
    },
    // 格式化时间  重启
    secondsFormatmin (s) {
      console.log('s', s)
      if (s <= 60) {
        return s + '秒'
      } else {
        var minute = Math.floor((s) / 60)
        var second = s - minute * 60
        return minute + '分' + second + '秒'
      }
    },
    // 格式化时间
    secondsFormat (s) {
      var day = Math.floor(s / (24 * 3600)) // Math.floor()向下取整
      var hour = Math.floor((s - day * 24 * 3600) / 3600)
      var minute = Math.floor((s - day * 24 * 3600 - hour * 3600) / 60)
      var second = s - day * 24 * 3600 - hour * 3600 - minute * 60
      return day + '天' + hour + '时' + minute + '分' + second + '秒'
    },
    reboot () {
      this.$confirm(
        '是否重启设备，重启设备需要1分钟左右？',
        '提示',
        {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
          center: true
        }
      )
        .then(() => {
          this.rebootrouter()
        })
        .catch(() => {
        })
    }
  }
}
</script>
<style scoped lang='scss'>
.home {
  height: 100%;
  margin-top: -20px;
}
.el-row {
  height: 100%;
}
.el-col {
  height: 100%;
}
.grid-content {
  height: 91%;
  display: flex;
  flex-direction: column;
  align-items: center;
  text-align: center;
  border-radius: 4px;
  padding: 20px 0;
}
.internet {
  text-align: center;
  width: 181px;
  height: 52px;
  line-height: 52px;
  background: rgba(255, 255, 255, 1);
  box-shadow: 0px 7px 16px 0px rgba(25, 29, 38, 0.15);
  border-radius: 10px;
}
.router {
  width: 118px;
  height: 118px;
  padding-top: 25px;
  text-align: center;
  background: rgba(255, 255, 255, 1);
  box-shadow: 0px 7px 16px 0px rgba(25, 29, 38, 0.15);
  border-radius: 10px;
}
.router-num {
  position: absolute;
  margin-left: 82px;
  width: 24px;
  height: 24px;
  line-height: 24px;
  color: #fff;
  border-radius: 50%;
  background: #b2b7c6;
}
.router-txt {
  width: 118px;
  margin-top: 10px;
}
.v-line {
  width: 2px;
  height: 40px;
  background: rgba(185, 190, 203, 1);
}
.h-line {
  width: 80%;
  height: 2px;
  background: rgba(185, 190, 203, 1);
}
.wrap {
  display: flex;
  width: calc(80% + 118px);
  align-items: flex-start;
  justify-content: space-between;
}
.router-item {
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
}
.wan {
  width: 85px;
  height: 85px;
  background: url("../assets/home/icon-bg-blue.png") no-repeat center;
  background-size: cover;
  img {
    margin-top: 26px;
  }
}
.speed {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 10%;
}
.speed-num {
  font-size: 28px;
  font-weight: 400;
  color: rgba(61, 147, 242, 1);
}
.wan-txt {
  margin-top: -20px;
}
.wifi-right,
.wifi-info,
.wan-info,
.speed,
.software-info,
.reboot {
  width: 100%;
  background: rgba(255, 255, 255, 1);
  box-shadow: 0px 20px 40px 0px rgba(48, 56, 73, 0.15);
  border-radius: 20px;
  cursor: pointer;
}
.wifi-info {
  text-align: left;
  height: 38.5%;
  padding-left: 10%;
  p {
    margin: 10px 0;
  }
  .signal-chanel {
    padding-top: 8%;
    p:first-child {
      margin-top: 0;
      margin-bottom: 16px;
    }
    p:last-child {
      margin-bottom: 0;
    }
  }
}
.reboot,
.wan-info {
  height: 16%;
}
.reboot {
  display: flex;
  justify-content: center;
  align-items: center;
}
.wan-info,
.software-info {
  padding-left: 10%;
  display: flex;
  flex-direction: column;
  justify-content: center;
  p:first-child {
    margin-bottom: 10px;
  }
  p:last-child {
    margin-top: 10px;
  }
}
.title {
  text-align: left;
  font-size: 24px;
  color: rgba(48, 56, 73, 1);
}

.online-device,
.runtime {
  width: 100%;
  height: 18%;
  background: linear-gradient(
    90deg,
    rgba(19, 230, 173, 1) 0%,
    rgba(61, 147, 242, 1) 100%
  );
  box-shadow: 0px 20px 40px 0px rgba(48, 56, 73, 0.15);
  border-radius: 20px;
}
.speed {
  height: 15%;
}
.software-info {
  height: 14.5%;
}
.signal-wrap {
  display: flex;
  justify-content: center;
  align-items: center;
}
.signal {
  display: flex;
  justify-content: center;
  align-items: center;
  width: 98px;
  height: 98px;
  line-height: 98px;
  border-radius: 50%;
  background: #fff;
}
.info-txt {
  display: flex;
  flex-direction: column;
  justify-content: center;
}
.info-content {
  margin-bottom: 10px;
  text-align: left;
  margin-left: 20%;
  color: #fff;
}
.device-number {
  margin-top: 10px;
  color: #fff;
  text-align: left;
  margin-left: 20%;
  .num {
    font-size: 36px;
    font-weight: bold;
  }
}
.el-icon-top {
  position: absolute;
  margin-left: -4px;
  font-size: 20px;
}
.top-num {
  margin-left: 22px;
}
::v-deep .el-dialog--center {
  margin-top: calc(50vh - 140px) !important;
  width: 400px !important;
  height: 280px;
  border-radius: 20px;
}
::v-deep .el-dialog__title {
  font-weight: 600;
}
::v-deep .el-dialog--center .el-dialog__body {
  text-align: center;
}
.el-icon-loading {
  font-size: 56px;
  color: #3d93f2;
}
::v-deep .el-dialog__header {
  padding: 40px;
  padding-bottom: 25px;
}
::v-deep .el-dialog__footer {
  padding: 20px;
  padding-top: 25px;
}
</style>
