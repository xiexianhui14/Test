
export function add() {
  return {
    type: 'add',
    data: 1
  }
};

export function sub() {
  return {
    type: 'sub',
    data: 1
  }
};