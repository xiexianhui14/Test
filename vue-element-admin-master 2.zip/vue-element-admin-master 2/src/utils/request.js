import axios from 'axios'
import { MessageBox, Message } from 'element-ui'

const currentUrl = window.location.href.split('#/')[1]

// let url = ''
// if (currentUrl === 'login') {
//   url = 'http://192.168.6.1/cgi-bin/luci/;stok=' + localStorage.getItem('token')
// } else {
//   'http://192.168.6.1/cgi-bin/luci'
// }

console.log('this.$route.path', window.location.href)
console.log('222', currentUrl)
// create an axios instance
const service = axios.create({
  // baseURL: process.env.VUE_APP_BASE_API, // url = base url + request url
  baseURL: '/cgi-bin/luci/', // url = base url + request url
  withCredentials: true, // send cookies when cross-domain requests
  timeout: 30000 // request timeout
})

// request interceptor
service.interceptors.request.use(
  config => {
    // do something before request is sent

    if (localStorage.getItem('token')) {
      // let each request carry token
      // ['X-Token'] is a custom headers key
      // please modify it according to the actual situation
    }
    return config
  },
  error => {
    // do something with request error
    console.log('aaaaa', error) // for debug
    return Promise.reject(error)
  }
)

// response interceptor
service.interceptors.response.use(
  /**
   * If you want to get http information such as headers or status
   * Please return  response => response
  */

  /**
   * Determine the request status by custom code
   * Here is just an example
   * You can also judge the status by HTTP Status Code
   */
  response => {
    console.log('response.statusCode', response)
    const res = response.data
    console.log('res', res)
    if(currentUrl==='systemlog' || currentUrl==='backupandrecover'){
      return response
    }else{
      if (res.code === 0) {
        return res
      } else if (res.code === 2) {
        Message({
          message: res.msg || '参数错误',
          type: 'error',
          duration: 2 * 1000
        })
      } else if (res.code === 1) {
        Message({
          message: res.msg || '密码错误',
          type: 'error',
          duration: 2 * 1000
        })
      } else if (res.code === 3) {
        Message({
          message: res.msg || '操作失败',
          type: 'error',
          duration: 2 * 1000
        })
      } else if (res.code === 4) {
        Message({
          message: res.msg || '未知错误',
          type: 'error',
          duration: 2 * 1000
        })
      } else {
        Message({
          message: res.msg || 'Error',
          type: 'error',
          duration: 2 * 1000
        })
      }
    }
    
   
  },
  error => {
    console.log('err', error) // for debug
    console.log('error.response', error.response.status) // for debug
    Message({
      message: error.message,
      type: 'error',
      duration: 30 * 1000
    })
    if (error.response.status === 403) {
      // localStorage.removeItem('token')
      // location.reload()
    }

    return Promise.reject(error)
  }
)

export default service
