<template>
  <div class="wifi-advanced-setting">
    <div class="wifi-wrap">
      <p class="txt title">Wi-Fi高级</p>
      <p class="tips">你可以对无线网络做更多个性化的设置，适应各种无线网络环境。</p>
      <p class="help">页面帮助</p>
      <div>
        <!-- 2.4g -->
        <div class="mode">
          <el-row :gutter="20">
            <el-col :span="10" class="title">
              2.4G WiFi
            </el-col>
          </el-row>
        </div>
        <div class="mode">
          <el-row :gutter="20">
            <el-col :span="10">
              2.4G WiFi信道
            </el-col>
            <el-col :span="14">
              <el-select v-model="channel2g" clearable placeholder="请选择">
                <el-option
                  v-for="item in channel2goptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-col>
          </el-row>
        </div>
        <div class="mode">
          <el-row :gutter="20">
            <el-col :span="10">
              模式
            </el-col>
            <el-col :span="14">
              <el-select v-model="hwmode2g" clearable placeholder="请选择">
                <el-option
                  v-for="item in hwmode2goptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-col>
          </el-row>
        </div>
        <div class="mode">
          <el-row :gutter="20">
            <el-col :span="10">
              Wi-Fi频宽设置
            </el-col>
            <el-col :span="14">
              <el-select v-model="htmode2g" clearable placeholder="请选择">
                <el-option
                  v-for="item in htmode2goptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-col>
          </el-row>
        </div>
        <div class="mode">
          <el-row :gutter="20">
            <el-col :span="10">
              Wi-Fi隐身
            </el-col>
            <el-col :span="14">
              <el-select v-model="hidden2g" clearable placeholder="请选择">
                <el-option
                  v-for="item in hidden2goptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-col>
          </el-row>
        </div>
        <div class="mode">
          <el-row :gutter="20">
            <el-col :span="10">
              WMM
            </el-col>
            <el-col :span="14">
              <el-select v-model="wmm2g" clearable placeholder="请选择">
                <el-option
                  v-for="item in wmm2goptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-col>
          </el-row>
        </div>

        <!-- 5g -->
        <div class="mode">
          <el-row :gutter="20">
            <el-col :span="10" class="title">
              5G WiFi
            </el-col>
          </el-row>
        </div>
        <div class="mode">
          <el-row :gutter="20">
            <el-col :span="10">
              5G WiFi信道
            </el-col>
            <el-col :span="14">
              <el-select v-model="channel5g" clearable placeholder="请选择">
                <el-option
                  v-for="item in channel5goptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-col>
          </el-row>
        </div>
        <div class="mode">
          <el-row :gutter="20">
            <el-col :span="10">
              模式
            </el-col>
            <el-col :span="14">
              <el-select v-model="hwmode5g" clearable placeholder="请选择">
                <el-option
                  v-for="item in hwmode5goptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-col>
          </el-row>
        </div>
        <div class="mode">
          <el-row :gutter="20">
            <el-col :span="10">
              Wi-Fi频宽设置
            </el-col>
            <el-col :span="14">
              <el-select v-model="htmode5g" clearable placeholder="请选择">
                <el-option
                  v-for="item in htmode5goptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-col>
          </el-row>
        </div>
        <div class="mode">
          <el-row :gutter="20">
            <el-col :span="10">
              Wi-Fi隐身
            </el-col>
            <el-col :span="14">
              <el-select v-model="hidden5g" clearable placeholder="请选择">
                <el-option
                  v-for="item in hidden5goptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-col>
          </el-row>
        </div>
        <div class="mode">
          <el-row :gutter="20">
            <el-col :span="10">
              WMM
            </el-col>
            <el-col :span="14">
              <el-select v-model="wmm5g" clearable placeholder="请选择">
                <el-option
                  v-for="item in wmm5goptions"
                  :key="item.value"
                  :label="item.label"
                  :value="item.value"
                />
              </el-select>
            </el-col>
          </el-row>
        </div>
      </div>

      <div class="save-wrap">
        <el-button type="primary" class="save" @click="savewifi">保存</el-button>
      </div>
    </div>
  </div>
</template>
<script>
import { get_wifi_adv_info, set_wifi_adv } from '@/api/article'
export default {
  data() {
    return {
      channel2g: '2',
      channel5g: 'auto',
      hwmode2g: '11b',
      hwmode5g: '11a',
      htmode2g: 'HT20',
      htmode5g: 'HT80',
      hidden2g: '0',
      hidden5g: '1',
      wmm2g: '0',
      wmm5g: '1',
      channel2goptions: [
        {
          value: '1',
          label: '1'
        },
        {
          value: '2',
          label: '2'
        },
        {
          value: '3',
          label: '3'
        },
        {
          value: '4',
          label: '4'
        },
        {
          value: '5',
          label: '5'
        },
        {
          value: '6',
          label: '6'
        },
        {
          value: '7',
          label: '7'
        },
        {
          value: '8',
          label: '8'
        },
        {
          value: '9',
          label: '9'
        },
        {
          value: '10',
          label: '10'
        },
        {
          value: '11',
          label: '11'
        },
        {
          value: '12',
          label: '12'
        },
        {
          value: '13',
          label: '13'
        },
        {
          value: 'auto',
          label: '自动'
        }

      ],
      channel5goptions: [
        {
          value: '36',
          label: '36'
        },
        {
          value: '40',
          label: '40'
        },
        {
          value: '44',
          label: '44'
        },
        {
          value: '48',
          label: '48'
        },
        {
          value: '52',
          label: '52'
        },
        {
          value: '56',
          label: '56'
        },
        {
          value: '60',
          label: '60'
        },
        {
          value: '64',
          label: '64'
        },
        {
          value: '149',
          label: '149'
        },
        {
          value: '153',
          label: '153'
        },
        {
          value: '157',
          label: '157'
        },
        {
          value: '161',
          label: '161'
        },
        {
          value: 'auto',
          label: '自动'
        }

      ],
      hwmode2goptions: [
        {
          value: '11b',
          label: '11b'
        },
        {
          value: '11g',
          label: '11b+11g'
        },
        {
          value: '11ng',
          label: '11b+11g+11n'
        },
        {
          value: '11axg',
          label: '11b+11g+11n+11ax'
        }
      ],
      hwmode5goptions: [
        {
          value: '11a',
          label: '11a'
        },
        {
          value: '11na',
          label: '11a+11n'
        },
        {
          value: '11ac',
          label: '11a+11n+11ac'
        },
        {
          value: '11axa',
          label: '11a+11g+11ac+11ax'
        }
      ],
      htmode2goptions: [
        {
          value: 'HT20',
          label: '20M'
        },
        {
          value: 'HT40',
          label: '40M'
        },
        {
          value: 'auto',
          label: '40/20MHz'
        }
      ],
      htmode5goptions: [
        {
          value: 'HT20',
          label: '20M'
        },
        {
          value: 'HT40',
          label: '40M'
        },
        {
          value: 'HT80',
          label: '80M'
        },
        {
          value: 'auto',
          label: '80/40/20MHz'
        }
      ],
      hidden2goptions: [
        {
          value: '0',
          label: '不隐身'
        },
        {
          value: '1',
          label: '隐身'
        }
      ],
      hidden5goptions: [
        {
          value: '0',
          label: '不隐身'
        },
        {
          value: '1',
          label: '隐身'
        }
      ],
      wmm2goptions: [
        {
          value: '0',
          label: '关闭'
        },
        {
          value: '1',
          label: '开启'
        }
      ],
      wmm5goptions: [
        {
          value: '0',
          label: '关闭'
        },
        {
          value: '1',
          label: '开启'
        }
      ]

    }
  },
  created() {
    this.get_wifi_info()
  },
  activated() {
  },
  deactivated() {
  },
  methods: {
    savewifi() {
      this.set_wifi()
    },
    get_wifi_info() {
      get_wifi_adv_info().then(response => {
        this.channel2g = response.wifi_ap_info['2g_channel']
        this.channel5g = response.wifi_ap_info['5g_channel']
        this.hwmode2g = response.wifi_ap_info['2g_hwmode']
        this.hwmode5g = response.wifi_ap_info['5g_hwmode']
        this.htmode2g = response.wifi_ap_info['2g_htmode']
        this.htmode5g = response.wifi_ap_info['5g_htmode']
        this.hidden2g = response.wifi_ap_info['2g_hidden']
        this.hidden5g = response.wifi_ap_info['5g_hidden']
        this.wmm2g = response.wifi_ap_info['2g_wmm']
        this.wmm5g = response.wifi_ap_info['5g_wmm']
      })
    },
    set_wifi() {
      const params = {
        '2g_hwmode': this.hwmode2g,
        '5g_hwmode': this.hwmode5g,
        '5g_channel': this.channel5g,
        '5g_htmode': this.htmode5g,
        '2g_wmm': this.wmm2g,
        '5g_wmm': this.wmm5g,
        '2g_htmode': this.htmode2g,
        '2g_channel': this.channel2g,
        '5g_hidden': this.hidden5g,
        '2g_hidden': this.hidden2g
      }
      set_wifi_adv(params).then(response => {
        this.$message({
          message: '成功',
          type: 'success',
          duration: 5 * 1000
        })
      })
    }

  }
}
</script>
<style scoped lang='scss'>
.wifi-advanced-setting {
  width: 100%;
  min-height: 100%;
  background: rgba(255, 255, 255, 1);
  box-shadow: 0px 20px 40px 0px rgba(48, 56, 73, 0.15);
  border-radius: 20px;
  .txt,.tips,.help {
    text-align: left;
    margin-left: 236px;
  }
  .title{
    font-size: 20px;
    font-weight: 600;
    margin-bottom: 10px;
  }
  .tips{
    margin-top: 10px;
  }
  .help{
    color:#53A9FD;
    cursor: pointer;
  }
  ::v-deep .el-col-10 {
    text-align: right;
    height: 36px;
    line-height: 36px;
  }
  ::v-deep .el-col-14 {
    text-align: left;
  }
}
.wifi-wrap {
  width: 800px;
  margin: 0 auto;
  text-align: center;
  padding-top: 24px;
  padding-bottom: 24px;
}
.input-wrap,
.select-wrap {
  margin-top: 22px;
}
.priority,
.wifi {
  margin-top: 14px;
  ::v-deep .el-col-10 {
    margin-top: -6px;
  }
}
.mode {
  margin-top: 22px;
}

.save-wrap {
  margin-left: 26%;
}
.save {
  margin-top: 20px;
}

</style>
