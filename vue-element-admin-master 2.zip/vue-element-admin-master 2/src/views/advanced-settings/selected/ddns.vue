<template>
<div>
ddns
</div>
  
</template>
<script>
export default {
  data() {
    return {
     
    }
  }
}
</script>
