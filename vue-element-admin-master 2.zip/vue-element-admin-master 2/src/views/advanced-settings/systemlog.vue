<template>
  <div class="system-log">
    <div class="log-wrap">
      <p class="txt title">系统日志</p>
      <p class="tips">系统日志记录设备的运行情况，设备出现故障时，可以分析出现故障原因。注意：开启断电保存，可实时保存日志到flash中， 但是会影响flash寿命，默认建议关闭。</p>
      <el-tabs v-model="activeName" @tab-click="handleClick">
        <el-tab-pane label="系统日志" name="syslog" class="sys-log" >{{syslog}}</el-tab-pane>
        <el-tab-pane label="内核日志" name="kernellog" class="core-log">{{kernellog}}</el-tab-pane>
        <el-tab-pane label="日志设置" name="syssetting" class="log-setting">日志设置</el-tab-pane>
      </el-tabs>

      <div class="save-wrap">
        <el-button type="primary" class="save" @click="fresh">刷新</el-button>
        <el-button type="primary" class="save" @click="exportTxt">保存日志</el-button>
      </div>
    </div>
  </div>
</template>
<script>
import { get_syslog } from '@/api/article'
export default {
  data() {
    return {
      activeName:"syslog",
      syslog:"",
      kernellog:"",
      params:{
        log_type : "system"
      },
      logdata:'',
      
    }
  },
  created() {
    this.get_syslog()
  },
  activated() {},
  deactivated() {},
  methods: {
    handleClick(tab, event) {
      if(tab.name==="syslog"){
        this.params = {
        log_type : "system"
      }
      this.get_syslog()
      }else if(tab.name==="kernellog"){
this.params = {
        log_type : "kernel"
      }
      this.get_syslog()
      }
    },
   fresh(){
     this.get_syslog()
   },
   
   exportTxt(){
     let res = this.logdata
 let blob = new Blob([res.data], { type: 'multipart/form-data' });
        //解码前的文件名
        let fileName1=res.headers['content-disposition'].split("=")[1].split(".")[0].replace('"',"");
        //解码
        let fileName=decodeURIComponent(fileName1);
        var filename = fileName+".txt";
        var a = document.createElement('a');
        var url = window.URL.createObjectURL(blob);
        a.href = url;
        a.download = filename;
        var body = document.getElementsByTagName('body')[0];
        body.appendChild(a);
        a.click();
        body.removeChild(a);
        window.URL.revokeObjectURL(url);
   },
    get_syslog() {
      
      get_syslog(this.params).then(res => {
         console.log("res",res)
        if(this.activeName==="syslog"){
          this.syslog = res.data
        } else if(this.activeName==="kernellog"){
          this.kernellog = res.data
        }
        this.logdata =res
        
        
      })
    }
    
  }
}
</script>
<style scoped lang='scss'>
.system-log {
  width: 100%;
  min-height: 100%;
  background: rgba(255, 255, 255, 1);
  box-shadow: 0px 20px 40px 0px rgba(48, 56, 73, 0.15);
  border-radius: 20px;
  .txt{
    text-align: left;
  }
   .tips{
     text-align: left;
    margin-top: 10px;
  }
  .title {
    font-size: 20px;
    font-weight: 600;
    margin-bottom: 10px;
  }

  ::v-deep .el-col-10 {
    text-align: right;
    height: 36px;
    line-height: 36px;
  }
  ::v-deep .el-col-14 {
    text-align: left;
  }

}
::v-deep .el-tabs__nav-wrap::after{
    background-color: transparent;
  }
.current_time{
  height: 36px;
  line-height: 36px;
}
.log-wrap {
  width: 800px;
  margin: 0 auto;
  text-align: center;
  padding-top: 24px;
  padding-bottom: 24px;
}
::v-deep .el-form-item__error{
 left:45%;
}
.mini {
  width: 66px;
}
.input-wrap,
.select-wrap {
  margin-top: 22px;
}
.sys-log,.core-log{
  white-space: pre-wrap;
}
.mode {
  margin-top: 22px;
}

.save-wrap {
  text-align: right;
}
.save {
  margin-top: 20px;
}
::v-deep  .el-tabs__active-bar{
  background-color: transparent;
}
::v-deep  .el-tabs__nav{
  padding: 20px;
}
::v-deep  .el-tabs__item{
  width:179px;
height:52px;
line-height: 52px;
margin-right: 20px;
font-size: 18px;
padding: 0;
background:rgba(255,255,255,1);
box-shadow:0px 13px 25px 0px rgba(25,29,38,0.15);
border-radius:20px;

}
::v-deep .el-tabs__item.is-active{
  background:linear-gradient(90deg,rgba(19,230,173,1) 0%,rgba(61,147,242,1) 100%);
box-shadow:0px 13px 25px 0px rgba(25,29,38,0.15);
color: #fff;
}
::v-deep .el-tabs__item.is-active:hover{
color: #fff;
}
 ::v-deep .el-tabs__item:hover {
    color: #303133;
    cursor: pointer;
}
::v-deep .el-tabs__content{
  height: 468px;
  padding: 20px;
background:rgba(236,237,240,1);
border-radius:20px;
}
.sys-log,.core-log{
  height: 428px;
  width: 100%;
  text-align: left;
  overflow: auto;
}
.log-setting{
  height: 468px;
    background: #fff;
    margin-top: -20px;
    width: 800px;
    margin-left: -20px;
}
</style>
