<template>
  <div class="systeminfo">
    <p class="device-info">
      <span>设备型号：{{ device_info.model }}</span>
      <span>软件版本号：{{ device_info.sw_version }}</span>
      <span>软件发布时间：{{ device_info.buildtime }}</span>
    </p>
    <el-row :gutter="40">
      <el-col :span="12">
        <div class="internet-info">
          <div class="title">外网信息</div>
          <el-row class="info">
            <el-col :span="12">
              <p>联网方式：{{ wan_info.proto }}</p>
              <p>联网状态：{{ wan_info.link_status === 0? '未联网' :'联网' }}</p>
              <p>IP地址：{{ wan_info.ipaddr }}</p>
              <p>子网掩码：{{ wan_info.netmask }}</p>
              <p>默认网关：{{ wan_info.gateway }}</p>
            </el-col>
            <el-col :span="12">
              <p>主域名服务器：{{ wan_info.dns1 }}</p>
              <p>次域名服务器：{{ wan_info.dns2 }}</p>
              <p>MAC地址：{{ wan_info.macaddr }}</p>
              <p>IPV6地址：{{ wan_info.ipaddr6 }}</p>
            </el-col>
          </el-row>
        </div>
        <div class="info-24g">
          <div class="title">局域网信息</div>
          <div class="info">
            <p>DHCF开关：{{ lan_info.dhcp_switch === 0? '关' :'开' }}</p>
            <p>IP地址：{{ lan_info.ipaddr }}</p>
            <p>子网掩码：{{ lan_info.netmask }}</p>
            <p>MAC地址：{{ lan_info.macaddr }}</p>
            <p>IPV6地址：{{ lan_info.ipaddr6 }}</p>
          </div>
        </div>
      </el-col>
      <el-col :span="12">
        <div class="LAN-info">
          <div class="title">2.4G WIFI信息</div>
          <div class="info">
            <p>无线名称：{{ wifi_info['2g_ssid'] }}</p>
            <p>加密方式：{{ wifi_info['2g_encmode'] }}</p>
            <p>信道：{{ wifi_info['2g_channel'] }}</p>
            <p>MAC地址：{{ wifi_info['2g_macaddr'] }}</p>
          </div>
        </div>
        <div class="info-5g">
          <div class="title">5G WIFI信息</div>
          <div class="info">
            <p>无线名称：{{ wifi_info['5g_ssid'] }}</p>
            <p>加密方式：{{ wifi_info['5g_encmode'] }}</p>
            <p>信道：{{ wifi_info['5g_channel'] }}</p>
            <p>MAC地址：{{ wifi_info['5g_macaddr'] }}</p>
          </div>
        </div>
      </el-col>
    </el-row>
  </div>
</template>
<script>
import { get_system_info } from '@/api/article'
export default {
  data() {
    return {
      lan_info: {},
      system_info: {},
      wan_info: {},
      device_info: {},
      wifi_info: {}
    }
  },
  created() {
    this.getSystemData()
  },
  methods: {
    getSystemData() {
      get_system_info().then(response => {
        console.log('response', response)
        this.lan_info = response.lan_info
        this.system_info = response.system_info
        this.wan_info = response.wan_info
        this.device_info = response.device_info
        this.wifi_info = response.wifi_info
      })
    }
  }
}
</script>
<style scoped lang='scss'>
.systeminfo {
  width: 100%;
  height: 99.5%;
  .device-info {
    margin-top: 4px;
    margin-bottom: 30px;
    span {
      padding-right: 50px;
      font-size: 20px;
    }
  }
  .el-row {
    height: calc(100% - 60px);
  }
  .el-col {
    height: 100%;
  }
  .internet-info,
  .LAN-info,
  .info-24g,
  .info-5g {
    width: 100%;
    height: calc(50% - 20px);
    padding: 20px 40px;
    background: rgba(255, 255, 255, 1);
    box-shadow: 0px 20px 40px 0px rgba(47, 55, 73, 0.15);
    border-radius: 20px;
  }
  .info-24g,
  .info-5g {
    margin-top: 40px;
  }
  .title {
    width: 179px;
    height: 52px;
    line-height: 52px;
    text-align: center;
    color: #fff;
    background: linear-gradient(
      90deg,
      rgba(19, 229, 173, 1) 0%,
      rgba(61, 147, 241, 1) 100%
    );
    box-shadow: 0px 13px 25px 0px rgba(25, 29, 37, 0.15);
    border-radius: 20px;
  }
  .info{
    padding-top: 20px;
  }
}
</style>
