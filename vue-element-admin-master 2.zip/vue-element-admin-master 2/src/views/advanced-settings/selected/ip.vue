<template>
<div>
ip
</div>
  
</template>
<script>
export default {
  data() {
    return {
     
    }
  }
}
</script>
