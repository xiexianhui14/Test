<template>
<div>
upnp
</div>
  
</template>
<script>
export default {
  data() {
    return {
     
    }
  }
}
</script>
